// src/data/products.js
export const CATEGORIES = [
  { id: 'women',       label: 'Women',       count: 240,
    image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600&q=80' },
  { id: 'men',         label: 'Men',         count: 185,
    image: 'https://images.unsplash.com/photo-1516257984-b1b4d707412e?w=600&q=80' },
  { id: 'streetwear',  label: 'Streetwear',  count: 120,
    image: 'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=600&q=80' },
  { id: 'hoodies',     label: 'Hoodies',     count: 64,
    image: 'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=600&q=80' },
  { id: 'sneakers',    label: 'Sneakers',    count: 98,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80' },
  { id: 'accessories', label: 'Accessories', count: 210,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=600&q=80' },
]

export const SIZES_CLOTHING = ['XS','S','M','L','XL','XXL']
export const SIZES_SHOES    = ['36','37','38','39','40','41','42','43','44','45']
export const SIZES_ONE      = ['One Size']

export const COLORS = [
  { name:'Black',    hex:'#1A1A1A' },
  { name:'White',    hex:'#FFFFFF' },
  { name:'Beige',    hex:'#E8E2D9' },
  { name:'Gold',     hex:'#C9A96E' },
  { name:'Navy',     hex:'#1A2035' },
  { name:'Burgundy', hex:'#6E1A2A' },
  { name:'Olive',    hex:'#4A5230' },
  { name:'Rose',     hex:'#D4A5A5' },
]

const now = new Date().toISOString()

export const PRODUCTS = [
  {
    id:'w-001', name:'Silk Reverie Blouse', brand:'VELORA', category:'women',
    price:189, oldPrice:null, badge:'new', featured:true, rating:4.9, reviews:128,
    sizes:SIZES_CLOTHING, colors:['Black','White','Beige'],
    tags:['silk','luxury','top'], sku:'VLR-W-001',
    description:'Crafted from 100% pure silk, this blouse drapes effortlessly over any silhouette. The subtle sheen catches light beautifully, transitioning from boardroom to dinner.',
    details:['100% Pure Silk','Dry Clean Only','Relaxed Fit','Invisible Side Zip','Made in Italy'],
    images:[
      'https://images.unsplash.com/photo-1564257631407-4deb1f99d992?w=800&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=80',
      'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=800&q=80',
    ],
    inStock:true, onSale:false, views:4520, createdAt:now,
  },
  {
    id:'w-002', name:'Velvet Blazer', brand:'VELORA', category:'women',
    price:420, oldPrice:560, badge:'sale', featured:true, rating:4.8, reviews:91,
    sizes:SIZES_CLOTHING, colors:['Black','Burgundy','Navy'],
    tags:['blazer','luxury','formal'], sku:'VLR-W-002',
    description:"Midnight velvet with a structured shoulder and single-button closure. The boardroom meets the runway in this season's most coveted tailoring piece.",
    details:['75% Cotton Velvet, 25% Silk','Structured Shoulder Padding','Fully Lined','Single Button Closure','Made in France'],
    images:[
      'https://images.unsplash.com/photo-1591369822096-ffd140ec948f?w=800&q=80',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800&q=80',
      'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=800&q=80',
    ],
    inStock:true, onSale:true, views:3100, createdAt:now,
  },
  {
    id:'w-003', name:'Amber Sand Linen Set', brand:'VELORA', category:'women',
    price:245, oldPrice:null, badge:'new', featured:true, rating:4.6, reviews:56,
    sizes:SIZES_CLOTHING, colors:['Beige','White','Olive'],
    tags:['linen','resort','set'], sku:'VLR-W-003',
    description:'Relaxed-fit linen co-ord set in our signature amber colorway. Perfect for resort and city alike.',
    details:['100% Belgian Linen','Oversized Blazer + Wide-Leg Trouser','Breathable Weave','Natural Finish','Sustainable Production'],
    images:[
      'https://images.unsplash.com/photo-1551163943-3f7fb696afbf?w=800&q=80',
      'https://images.unsplash.com/photo-1496747611176-843222e1e57c?w=800&q=80',
      'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&q=80',
    ],
    inStock:true, onSale:false, views:2890, createdAt:now,
  },
  {
    id:'w-004', name:'Obsidian Column Dress', brand:'VELORA ATELIER', category:'women',
    price:580, oldPrice:null, badge:'new', featured:false, rating:4.7, reviews:42,
    sizes:SIZES_CLOTHING, colors:['Black'],
    tags:['dress','formal','evening'], sku:'VLR-W-004',
    description:'A floor-length column dress in matte obsidian crepe. Architectural simplicity at its most powerful.',
    details:['100% Crepe de Chine','Floor Length','Side Slit','Hidden Back Zip','Dry Clean Only'],
    images:[
      'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&q=80',
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=800&q=80',
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=800&q=80',
    ],
    inStock:true, onSale:false, views:1890, createdAt:now,
  },
  {
    id:'w-005', name:'Camel Wrap Coat', brand:'VELORA', category:'women',
    price:695, oldPrice:null, badge:'new', featured:true, rating:4.9, reviews:73,
    sizes:SIZES_CLOTHING, colors:['Beige','Black'],
    tags:['coat','outerwear','winter','luxury'], sku:'VLR-W-005',
    description:'The definitive luxury wrap coat. Oversized camel wool with a dramatic lapel and self-tie belt.',
    details:['100% Virgin Wool','Oversized Fit','Self-Tie Belt','Deep Side Pockets','Dry Clean Only'],
    images:[
      'https://images.unsplash.com/photo-1548624313-0396c75e4b1a?w=800&q=80',
      'https://images.unsplash.com/photo-1525507119028-ed4c629a60a3?w=800&q=80',
      'https://images.unsplash.com/photo-1585487000160-6ebcfceb0d03?w=800&q=80',
    ],
    inStock:true, onSale:false, views:3400, createdAt:now,
  },
  {
    id:'m-001', name:'Obsidian Bomber', brand:'VELORA × NOIR', category:'men',
    price:329, oldPrice:480, badge:'sale', featured:true, rating:4.7, reviews:84,
    sizes:SIZES_CLOTHING, colors:['Black','Navy'],
    tags:['bomber','luxury','outerwear'], sku:'VLR-M-001',
    description:'A collaboration piece fusing streetwear edge with luxury tailoring. Heavyweight satin finish, contrast rib trim, subtle logo embroidery.',
    details:['Heavyweight Satin Shell','Contrast Rib Trim','Satin Lining','Embroidered Logo','Limited Edition'],
    images:[
      'https://images.unsplash.com/photo-1520975954732-35dd22299614?w=800&q=80',
      'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&q=80',
    ],
    inStock:true, onSale:true, views:5200, createdAt:now,
  },
  {
    id:'m-002', name:'Desert Cargo Pants', brand:'VELORA STREET', category:'men',
    price:198, oldPrice:null, badge:'hot', featured:true, rating:4.7, reviews:167,
    sizes:['28','30','32','34','36'], colors:['Beige','Olive','Black'],
    tags:['cargo','streetwear','pants'], sku:'VLR-M-002',
    description:'Washed cotton cargo with utility pockets and relaxed taper. The everyday statement piece.',
    details:['100% Stone-Washed Cotton','6-Pocket Utility Design','Elasticated Waistband','Relaxed Taper Fit','Reinforced Knees'],
    images:[
      'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=800&q=80',
      'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800&q=80',
      'https://images.unsplash.com/photo-1591195853828-11db59a44f43?w=800&q=80',
    ],
    inStock:true, onSale:false, views:3890, createdAt:now,
  },
  {
    id:'m-003', name:'Ivory Boucle Overcoat', brand:'VELORA', category:'men',
    price:695, oldPrice:null, badge:'new', featured:false, rating:4.9, reviews:28,
    sizes:SIZES_CLOTHING, colors:['White','Beige','Black'],
    tags:['coat','luxury','outerwear','winter'], sku:'VLR-M-003',
    description:'Ivory boucle wool overcoat with notch lapel and single-breasted closure. Refined masculinity.',
    details:['85% Wool, 15% Cashmere','Fully Silk-Lined','Notch Lapel','Single Breasted','Made in England'],
    images:[
      'https://images.unsplash.com/photo-1600180758890-6b94519a8ba6?w=800&q=80',
      'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?w=800&q=80',
      'https://images.unsplash.com/photo-1490578474895-699cd4e2cf59?w=800&q=80',
    ],
    inStock:true, onSale:false, views:1240, createdAt:now,
  },
  {
    id:'m-004', name:'Linen Resort Shirt', brand:'VELORA', category:'men',
    price:145, oldPrice:null, badge:'hot', featured:true, rating:4.6, reviews:112,
    sizes:SIZES_CLOTHING, colors:['White','Beige','Olive'],
    tags:['shirt','linen','resort','summer'], sku:'VLR-M-004',
    description:'Lightweight linen shirt with a relaxed open collar. The summer essential.',
    details:['100% European Linen','Relaxed Fit','Camp Collar','Mother-of-Pearl Buttons','Machine Washable'],
    images:[
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&q=80',
      'https://images.unsplash.com/photo-1598032895397-b9472444bf93?w=800&q=80',
      'https://images.unsplash.com/photo-1607345366928-199ea26cfe3e?w=800&q=80',
    ],
    inStock:true, onSale:false, views:2700, createdAt:now,
  },
  {
    id:'s-001', name:'Noir Oversized Hoodie', brand:'VELORA STREET', category:'streetwear',
    price:175, oldPrice:220, badge:'sale', featured:true, rating:4.5, reviews:142,
    sizes:SIZES_CLOTHING, colors:['Black','White','Olive'],
    tags:['hoodie','streetwear','casual'], sku:'VLR-S-001',
    description:'The ultimate streetwear staple. Heavyweight French terry with embroidered VELORA logo.',
    details:['400gsm French Terry','Embroidered Logo','Kangaroo Pocket','Adjustable Hood','Pre-Washed'],
    images:[
      'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=800&q=80',
      'https://images.unsplash.com/photo-1578681994506-b8f463449011?w=800&q=80',
      'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?w=800&q=80',
    ],
    inStock:true, onSale:true, views:6700, createdAt:now,
  },
  {
    id:'s-002', name:'Monogram Track Jacket', brand:'VELORA STREET', category:'streetwear',
    price:195, oldPrice:null, badge:'hot', featured:false, rating:4.4, reviews:98,
    sizes:SIZES_CLOTHING, colors:['Black','Beige'],
    tags:['jacket','streetwear','track'], sku:'VLR-S-002',
    description:'Statement track jacket with all-over VELORA monogram print. Relaxed fit, zip-through, contrast piping.',
    details:['Cotton-Nylon Blend','Monogram Print','Zip-Through','Contrast Piping','Side Pockets'],
    images:[
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&q=80',
      'https://images.unsplash.com/photo-1552346154-21d32810aba3?w=800&q=80',
      'https://images.unsplash.com/photo-1544441893-675973e31985?w=800&q=80',
    ],
    inStock:true, onSale:false, views:2340, createdAt:now,
  },
  {
    id:'h-001', name:'Cashmere Blend Hoodie', brand:'VELORA', category:'hoodies',
    price:320, oldPrice:null, badge:'new', featured:true, rating:4.9, reviews:67,
    sizes:SIZES_CLOTHING, colors:['Beige','Black','Rose'],
    tags:['hoodie','luxury','cashmere'], sku:'VLR-H-001',
    description:'A luxurious take on the hoodie. 40% cashmere blend for unmatched softness.',
    details:['40% Cashmere, 60% Organic Cotton','Relaxed Oversized Fit','Ribbed Cuffs & Hem','Tonal Embroidery','OEKO-TEX Certified'],
    images:[
      'https://images.unsplash.com/photo-1620799139652-3f9c8532568e?w=800&q=80',
      'https://images.unsplash.com/photo-1509942774463-acf339cf87d5?w=800&q=80',
      'https://images.unsplash.com/photo-1503342394128-c104d54dba01?w=800&q=80',
    ],
    inStock:true, onSale:false, views:2100, createdAt:now,
  },
  {
    id:'sn-001', name:'Cloud Step Sneakers', brand:'VELORA SPORT', category:'sneakers',
    price:265, oldPrice:null, badge:'hot', featured:true, rating:4.8, reviews:203,
    sizes:SIZES_SHOES, colors:['White','Black','Beige'],
    tags:['sneakers','sport','luxury'], sku:'VLR-SN-001',
    description:'Engineered foam cushioning meets runway aesthetics. The Cloud Step silhouette redefines athletic luxury.',
    details:['Full-Grain Leather Upper','Engineered Foam Midsole','Rubber Outsole','OrthoLite Insole','Comes in Dust Bag'],
    images:[
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80',
      'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=800&q=80',
      'https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?w=800&q=80',
    ],
    inStock:true, onSale:false, views:8900, createdAt:now,
  },
  {
    id:'sn-002', name:'Eclipse Low-Top', brand:'VELORA SPORT', category:'sneakers',
    price:195, oldPrice:260, badge:'sale', featured:false, rating:4.6, reviews:88,
    sizes:SIZES_SHOES, colors:['Black','White'],
    tags:['sneakers','sport','low-top'], sku:'VLR-SN-002',
    description:'Sleek low-top silhouette with contrast sole unit. Minimal branding — maximum impact.',
    details:['Perforated Leather','Contrast Rubber Sole','Cushioned Footbed','Metal Eyelets','Extra Lace Set Included'],
    images:[
      'https://images.unsplash.com/photo-1600269452121-4f2416e55c28?w=800&q=80',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?w=800&q=80',
      'https://images.unsplash.com/photo-1539185441755-769473a23570?w=800&q=80',
    ],
    inStock:true, onSale:true, views:3400, createdAt:now,
  },
  {
    id:'a-001', name:'Gold Capsule Watch', brand:'VELORA ATELIER', category:'accessories',
    price:589, oldPrice:null, badge:'new', featured:true, rating:5.0, reviews:34,
    sizes:SIZES_ONE, colors:['Gold','Black'],
    tags:['watch','luxury','accessories'], sku:'VLR-A-001',
    description:'Swiss quartz movement in a gold-plated stainless steel case. Limited to 500 pieces worldwide.',
    details:['Swiss Quartz Movement','Gold-Plated Steel Case','Sapphire Crystal Glass','3 ATM Water Resistant','Limited Edition — Numbered'],
    images:[
      'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800&q=80',
      'https://images.unsplash.com/photo-1619134778706-7015533a6150?w=800&q=80',
      'https://images.unsplash.com/photo-1587836374828-4dbafa94cf0e?w=800&q=80',
    ],
    inStock:true, onSale:false, views:1500, createdAt:now,
  },
  {
    id:'a-002', name:'Leather Tote Grande', brand:'VELORA', category:'accessories',
    price:395, oldPrice:null, badge:'new', featured:true, rating:4.8, reviews:61,
    sizes:SIZES_ONE, colors:['Black','Beige','Burgundy'],
    tags:['bag','leather','accessories'], sku:'VLR-A-002',
    description:'Structured full-grain leather tote with gold hardware. Spacious interior with suede lining and magnetic closure.',
    details:['Full-Grain Leather','Suede Interior Lining','Laptop Sleeve','Gold Plated Hardware','Includes Dust Bag & Care Kit'],
    images:[
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=800&q=80',
      'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&q=80',
      'https://images.unsplash.com/photo-1594938298603-c8148c4b4471?w=800&q=80',
    ],
    inStock:true, onSale:false, views:2600, createdAt:now,
  },
]

export const HERO_SLIDES = [
  {
    tag:'Summer Collection 2026',
    title:'Dress for the Story\nYou\'re Writing',
    sub:'Curated pieces for the bold, the refined, the effortlessly elevated.',
    image:'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1600&q=85',
    cta:'Explore Collection', link:'/products',
  },
  {
    tag:'Resort Drop 2026',
    title:'Where Luxury Meets\nthe Everyday',
    sub:'Relaxed silhouettes crafted for the world-traveller with refined taste.',
    image:'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1600&q=85',
    cta:'Shop Resort', link:'/products?badge=new',
  },
  {
    tag:'Capsule Series',
    title:'Less is\nEverything',
    sub:'Twelve defining pieces. Infinite combinations. One unforgettable wardrobe.',
    image:'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=1600&q=85',
    cta:'View Capsule', link:'/lookbook',
  },
]

export const LOOKBOOK_ITEMS = [
  { season:'Summer 2026', title:'Desert Noir',   image:'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=800&q=80', link:'/lookbook' },
  { season:'Resort 2026', title:'Midnight Blue', image:'https://images.unsplash.com/photo-1594938298603-c8148c4b4471?w=800&q=80', link:'/lookbook' },
  { season:'Capsule 2026',title:'Velvet Dusk',   image:'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=800&q=80', link:'/lookbook' },
]

export const GALLERY_IMAGES = [
  'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=600&q=80',
  'https://images.unsplash.com/photo-1512436991641-6745cdb1723f?w=600&q=80',
  'https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=600&q=80',
  'https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&q=80',
  'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=600&q=80',
  'https://images.unsplash.com/photo-1551163943-3f7fb696afbf?w=600&q=80',
]

export const TESTIMONIALS = [
  { text:'VELORA changed how I see fashion. Every piece is a conversation — I get compliments every single time. The quality is absolutely unmatched.', name:'Sophia Laurent', meta:'Fashion Editor, Paris', initials:'SL', avatar:'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&q=80' },
  { text:'The lookbooks are pure art. I bought three pieces from the Desert Noir collection — absolute gems. Shipping flawless, packaging felt like unwrapping a gift.', name:'Marcus Chen', meta:'Creative Director', initials:'MC', avatar:'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&q=80' },
  { text:"I've shopped at every luxury brand. VELORA hits that rare sweet spot — elevated design with real wearability. My wardrobe finally tells a coherent story.", name:'Aisha Okonkwo', meta:'Brand Strategist', initials:'AO', avatar:'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=100&q=80' },
]

export const getProductsByCategory = (cat) => PRODUCTS.filter(p => p.category === cat)
export const getFeaturedProducts   = ()    => PRODUCTS.filter(p => p.featured)
export const getSaleProducts       = ()    => PRODUCTS.filter(p => p.onSale || p.oldPrice)
export const getRelatedProducts    = (product, count=4) =>
  PRODUCTS.filter(p => p.id !== product.id && p.category === product.category).slice(0, count)
