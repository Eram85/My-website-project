import { useState, useEffect, useRef, useCallback } from 'react'

export function useScrollProgress() {
  const [progress, setProgress] = useState(0)
  useEffect(() => {
    const handler = () => {
      const doc = document.documentElement
      const pct = (doc.scrollTop / (doc.scrollHeight - doc.clientHeight)) * 100
      setProgress(isNaN(pct) ? 0 : pct)
    }
    window.addEventListener('scroll', handler, { passive:true })
    return () => window.removeEventListener('scroll', handler)
  }, [])
  return progress
}

export function useNavScroll(threshold = 60) {
  const [scrolled, setScrolled] = useState(false)
  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > threshold)
    window.addEventListener('scroll', handler, { passive:true })
    return () => window.removeEventListener('scroll', handler)
  }, [threshold])
  return scrolled
}

export function useCountdown(targetSeconds) {
  const [secs, setSecs] = useState(targetSeconds)
  useEffect(() => {
    const id = setInterval(() => setSecs(s => Math.max(0, s-1)), 1000)
    return () => clearInterval(id)
  }, [])
  const h = Math.floor(secs / 3600)
  const m = Math.floor((secs % 3600) / 60)
  const s = secs % 60
  return { hours:String(h).padStart(2,'0'), minutes:String(m).padStart(2,'0'), seconds:String(s).padStart(2,'0'), done:secs===0 }
}

export function useDebounce(value, delay = 300) {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const id = setTimeout(() => setDebounced(value), delay)
    return () => clearTimeout(id)
  }, [value, delay])
  return debounced
}

export function useClickOutside(ref, handler) {
  useEffect(() => {
    const listener = e => { if (!ref.current || ref.current.contains(e.target)) return; handler(e) }
    document.addEventListener('mousedown', listener)
    document.addEventListener('touchstart', listener)
    return () => { document.removeEventListener('mousedown', listener); document.removeEventListener('touchstart', listener) }
  }, [ref, handler])
}

export function useLockBodyScroll(locked) {
  useEffect(() => {
    if (locked) {
      const y = window.scrollY
      document.body.style.overflow = 'hidden'
      document.body.style.position = 'fixed'
      document.body.style.top = `-${y}px`
      document.body.style.width = '100%'
      return () => {
        document.body.style.overflow = ''
        document.body.style.position = ''
        document.body.style.top = ''
        document.body.style.width = ''
        window.scrollTo(0, y)
      }
    }
  }, [locked])
}

export function useLocalStorage(key, initial) {
  const [val, setVal] = useState(() => {
    try { return JSON.parse(localStorage.getItem(key)) ?? initial }
    catch { return initial }
  })
  useEffect(() => { try { localStorage.setItem(key, JSON.stringify(val)) } catch {} }, [key, val])
  return [val, setVal]
}
