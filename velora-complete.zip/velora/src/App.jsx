import { Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './context/AuthContext'
import Navbar from './components/layout/Navbar'
import Footer from './components/layout/Footer'
import CartDrawer from './components/cart/CartDrawer'
import QuickViewModal from './components/product/QuickViewModal'
import FloatingChat from './components/ui/FloatingChat'
import ScrollProgress from './components/ui/ScrollProgress'
import Home from './pages/Home'
import Products from './pages/Products'
import ProductDetail from './pages/ProductDetail'
import Auth from './pages/Auth'
import Account from './pages/Account'
import Checkout from './pages/Checkout'
import OrderConfirmation from './pages/OrderConfirmation'
import Wishlist from './pages/Wishlist'
import Lookbook from './pages/Lookbook'
import About from './pages/About'
import Contact from './pages/Contact'
import FAQ from './pages/FAQ'
import AdminDashboard from './pages/AdminDashboard'
import AIStylist from './pages/AIStylist'
import NotFound from './pages/NotFound'

export default function App() {
  return (
    <AuthProvider>
      <ScrollProgress />
      <Navbar />
      <CartDrawer />
      <QuickViewModal />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/products" element={<Products />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/account" element={<Account />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/order-confirmation" element={<OrderConfirmation />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/lookbook" element={<Lookbook />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/ai-stylist" element={<AIStylist />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
      <FloatingChat />
      <Toaster
        position="top-right"
        toastOptions={{
          style: { background:'#1A1A1A', color:'#fff', borderLeft:'3px solid #C9A96E', borderRadius:0, fontSize:'13px' },
          success: { style: { borderLeftColor:'#4CAF50' } },
          error:   { style: { borderLeftColor:'#ef4444' } },
        }}
      />
    </AuthProvider>
  )
}
