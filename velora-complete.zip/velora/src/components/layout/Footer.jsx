// src/components/layout/Footer.jsx
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { isValidEmail } from '../../utils'

const footerLinks = {
  Shop: [
    { label: 'New Arrivals', to: '/products?badge=new' },
    { label: 'Women',        to: '/products?category=women' },
    { label: 'Men',          to: '/products?category=men' },
    { label: 'Accessories',  to: '/products?category=accessories' },
    { label: 'Lookbook',     to: '/lookbook' },
    { label: 'Sale',         to: '/products?sale=true' },
  ],
  Help: [
    { label: 'Shipping & Returns', to: '/shipping' },
    { label: 'Size Guide',         to: '/size-guide' },
    { label: 'Contact Us',         to: '/contact' },
    { label: 'FAQ',                to: '/faq' },
    { label: 'Track Order',        to: '/account?tab=orders' },
  ],
  Company: [
    { label: 'About VELORA',  to: '/about' },
    { label: 'Sustainability', to: '/about#sustainability' },
    { label: 'Press',          to: '/about#press' },
    { label: 'Careers',        to: '/careers' },
    { label: 'Privacy Policy', to: '/privacy' },
    { label: 'Terms',          to: '/terms' },
  ],
}

const socials = [
  { label: 'IG', title: 'Instagram',  href: '#' },
  { label: 'PT', title: 'Pinterest',  href: '#' },
  { label: 'TK', title: 'TikTok',     href: '#' },
  { label: 'TW', title: 'X/Twitter',  href: '#' },
]

export default function Footer() {
  const [email, setEmail] = useState('')

  const handleSubscribe = () => {
    if (!isValidEmail(email)) {
      toast.error('Please enter a valid email')
      return
    }
    toast.success('Welcome to the VELORA family! 💌')
    setEmail('')
  }

  return (
    <footer className="bg-charcoal text-white">
      {/* Top strip */}
      <div className="border-b border-white/10 py-6">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-8 h-px bg-gold" />
            <span className="text-[11px] tracking-[0.3em] uppercase text-gold">Free Shipping Over $200</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="w-8 h-px bg-gold" />
            <span className="text-[11px] tracking-[0.3em] uppercase text-gold">30-Day Free Returns</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="w-8 h-px bg-gold" />
            <span className="text-[11px] tracking-[0.3em] uppercase text-gold">Authenticity Guaranteed</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="w-8 h-px bg-gold" />
            <span className="text-[11px] tracking-[0.3em] uppercase text-gold">Secure Checkout</span>
          </div>
        </div>
      </div>

      {/* Main */}
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 lg:gap-16">

          {/* Brand */}
          <div className="lg:col-span-2">
            <Link to="/" className="font-display text-3xl tracking-[0.35em] uppercase font-light block mb-4">
              VELORA
            </Link>
            <p className="text-sm text-white/50 leading-relaxed mb-6 max-w-xs">
              Luxury fashion for the bold. Curated collections that transcend trends. Wear the story you want to tell.
            </p>

            {/* Newsletter */}
            <p className="text-[10px] tracking-[0.3em] uppercase text-gold mb-3">Join the Club</p>
            <div className="flex">
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="Your email..."
                onKeyDown={e => e.key === 'Enter' && handleSubscribe()}
                className="flex-1 bg-white/8 border border-white/15 px-4 py-3 text-sm text-white placeholder:text-white/40 outline-none focus:border-gold transition-colors"
              />
              <button
                onClick={handleSubscribe}
                className="bg-gold text-white px-5 text-[11px] tracking-widest uppercase font-medium hover:bg-accent transition-colors"
              >
                Join
              </button>
            </div>

            {/* Socials */}
            <div className="flex gap-3 mt-6">
              {socials.map(s => (
                <a
                  key={s.label}
                  href={s.href}
                  title={s.title}
                  className="w-9 h-9 border border-white/15 flex items-center justify-center text-xs text-white/50 hover:border-gold hover:text-gold transition-all duration-200"
                >
                  {s.label}
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(footerLinks).map(([heading, links]) => (
            <div key={heading}>
              <p className="text-[10px] tracking-[0.3em] uppercase text-white/35 mb-5 font-medium">{heading}</p>
              <ul className="space-y-3">
                {links.map(l => (
                  <li key={l.label}>
                    <Link to={l.to} className="text-sm text-white/55 hover:text-gold transition-colors duration-200">
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom */}
      <div className="border-t border-white/8 py-6">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10 flex flex-wrap items-center justify-between gap-4">
          <p className="text-xs text-white/30">© 2026 VELORA. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span className="text-[11px] text-white/30 tracking-widest">🔒 SECURE CHECKOUT</span>
            <span className="text-[11px] text-white/30">VISA · MC · AMEX · STRIPE</span>
          </div>
          <div className="flex gap-6">
            {['Privacy', 'Terms', 'Cookies'].map(l => (
              <Link key={l} to={`/${l.toLowerCase()}`} className="text-xs text-white/30 hover:text-white/60 transition-colors">
                {l}
              </Link>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
