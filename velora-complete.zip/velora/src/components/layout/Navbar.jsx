// src/components/layout/Navbar.jsx
import { useState, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useNavScroll, useClickOutside, useDebounce } from '../../hooks'
import { useCartStore, useWishlistStore, useUIStore } from '../../context/useStore'
import { useAuth } from '../../context/AuthContext'
import { PRODUCTS } from '../../data/products'

// Icons (inline SVG)
const SearchIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-5 h-5">
    <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
  </svg>
)
const UserIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-5 h-5">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
  </svg>
)
const HeartIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-5 h-5">
    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
  </svg>
)
const BagIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-5 h-5">
    <path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
    <line x1="3" y1="6" x2="21" y2="6"/>
    <path d="M16 10a4 4 0 0 1-8 0"/>
  </svg>
)
const SunIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-4 h-4"><circle cx="12" cy="12" r="5"/><path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>
const MoonIcon = () => <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="w-4 h-4"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>

const NAV_ITEMS = [
  { label: 'Shop', hasMega: true },
  { label: 'Lookbook', to: '/lookbook' },
  { label: 'New In', to: '/products?badge=new' },
  { label: 'Sale', to: '/products?sale=true' },
  { label: 'About', to: '/about' },
]

const MEGA_COLS = [
  {
    title: 'Women',
    links: ['New Arrivals', 'Dresses', 'Tops & Blouses', 'Outerwear', 'Accessories', 'Sale'],
    cat: 'women',
  },
  {
    title: 'Men',
    links: ['New Arrivals', 'Shirts', 'Streetwear', 'Hoodies', 'Sneakers', 'Sale'],
    cat: 'men',
  },
  {
    title: 'Collections',
    links: ['Summer 2026', 'Resort Drop', 'Capsule Series', 'Limited Editions', 'Collaborations'],
    cat: null,
  },
]

export default function Navbar() {
  const scrolled = useNavScroll()
  const { toggleCart, itemCount } = useCartStore()
  const wishlistCount = useWishlistStore(s => s.items.length)
  const { searchOpen, toggleSearch, darkMode, toggleDarkMode, megaMenuOpen, openMegaMenu, closeMegaMenu } = useUIStore()
  const { user } = useAuth()
  const navigate = useNavigate()

  const [searchQuery, setSearchQuery] = useState('')
  const [mobileOpen, setMobileOpen] = useState(false)
  const debouncedQ = useDebounce(searchQuery, 200)
  const megaTimeout = useRef(null)

  const searchResults = debouncedQ.length > 1
    ? PRODUCTS.filter(p =>
        p.name.toLowerCase().includes(debouncedQ.toLowerCase()) ||
        p.category.toLowerCase().includes(debouncedQ.toLowerCase()) ||
        p.tags?.some(t => t.includes(debouncedQ.toLowerCase()))
      ).slice(0, 5)
    : []

  const handleMegaEnter = () => {
    clearTimeout(megaTimeout.current)
    openMegaMenu()
  }
  const handleMegaLeave = () => {
    megaTimeout.current = setTimeout(closeMegaMenu, 250)
  }

  return (
    <>
      {/* Navbar */}
      <motion.nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          scrolled
            ? 'bg-cream/95 backdrop-blur-md border-b border-beige shadow-sm'
            : 'bg-transparent'
        }`}
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, ease: [0.25, 0.46, 0.45, 0.94] }}
      >
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10 h-[72px] flex items-center justify-between">

          {/* Hamburger (mobile) */}
          <button
            className="lg:hidden flex flex-col gap-1.5 p-1"
            onClick={() => setMobileOpen(o => !o)}
            aria-label="Menu"
          >
            <span className={`w-6 h-px bg-charcoal block transition-all duration-300 ${mobileOpen ? 'rotate-45 translate-y-2' : ''}`} />
            <span className={`w-6 h-px bg-charcoal block transition-all duration-300 ${mobileOpen ? 'opacity-0' : ''}`} />
            <span className={`w-6 h-px bg-charcoal block transition-all duration-300 ${mobileOpen ? '-rotate-45 -translate-y-2' : ''}`} />
          </button>

          {/* Logo */}
          <Link
            to="/"
            className="font-display text-2xl tracking-[0.35em] uppercase font-light text-charcoal hover:text-gold transition-colors duration-300"
          >
            VELORA
          </Link>

          {/* Desktop Nav */}
          <ul className="hidden lg:flex items-center gap-8">
            {NAV_ITEMS.map(item => (
              <li key={item.label}>
                {item.hasMega ? (
                  <button
                    onMouseEnter={handleMegaEnter}
                    onMouseLeave={handleMegaLeave}
                    className="text-[11px] tracking-[0.2em] uppercase font-medium text-charcoal/80 hover:text-charcoal transition-colors hover-line"
                    onClick={() => navigate('/products')}
                  >
                    {item.label}
                  </button>
                ) : (
                  <Link
                    to={item.to}
                    className="text-[11px] tracking-[0.2em] uppercase font-medium text-charcoal/80 hover:text-charcoal transition-colors hover-line"
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>

          {/* Actions */}
          <div className="flex items-center gap-3">
            {/* Dark mode */}
            <button
              onClick={toggleDarkMode}
              className="hidden md:flex w-8 h-8 items-center justify-center text-charcoal/60 hover:text-charcoal transition-colors"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <SunIcon /> : <MoonIcon />}
            </button>

            {/* Search */}
            <button
              onClick={toggleSearch}
              className="w-9 h-9 flex items-center justify-center text-charcoal/80 hover:text-charcoal transition-colors hover:scale-110 duration-200"
              aria-label="Search"
            >
              <SearchIcon />
            </button>

            {/* Wishlist */}
            <Link
              to="/wishlist"
              className="relative w-9 h-9 flex items-center justify-center text-charcoal/80 hover:text-charcoal transition-colors hover:scale-110 duration-200"
              aria-label="Wishlist"
            >
              <HeartIcon />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-rose text-white text-[9px] rounded-full flex items-center justify-center font-semibold">
                  {wishlistCount}
                </span>
              )}
            </Link>

            {/* Cart */}
            <button
              onClick={toggleCart}
              className="relative w-9 h-9 flex items-center justify-center text-charcoal/80 hover:text-charcoal transition-colors hover:scale-110 duration-200"
              aria-label="Cart"
            >
              <BagIcon />
              {itemCount > 0 && (
                <motion.span
                  key={itemCount}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="absolute top-1 right-1 w-4 h-4 bg-gold text-white text-[9px] rounded-full flex items-center justify-center font-semibold"
                >
                  {itemCount}
                </motion.span>
              )}
            </button>

            {/* User */}
            <Link
              to={user ? '/account' : '/auth'}
              className="hidden md:flex items-center gap-2 text-[11px] tracking-widest uppercase font-medium border border-charcoal px-4 py-2 hover:bg-charcoal hover:text-cream transition-all duration-300"
            >
              <UserIcon />
              {user ? user.displayName?.split(' ')[0] || 'Account' : 'Sign In'}
            </Link>
          </div>
        </div>
      </motion.nav>

      {/* Mega Menu */}
      <AnimatePresence>
        {megaMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="fixed top-[72px] left-0 right-0 bg-white border-b border-beige shadow-xl z-40"
            onMouseEnter={handleMegaEnter}
            onMouseLeave={handleMegaLeave}
          >
            <div className="max-w-screen-xl mx-auto px-10 py-10 grid grid-cols-4 gap-12">
              {MEGA_COLS.map(col => (
                <div key={col.title}>
                  <p className="text-[10px] tracking-[0.3em] uppercase text-gold font-medium mb-4">{col.title}</p>
                  <ul className="space-y-3">
                    {col.links.map(link => (
                      <li key={link}>
                        <Link
                          to={col.cat ? `/products?category=${col.cat}` : '/products'}
                          className="text-sm text-charcoal/70 hover:text-charcoal hover:pl-2 transition-all duration-200"
                          onClick={closeMegaMenu}
                        >
                          {link}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              {/* Featured */}
              <div>
                <p className="text-[10px] tracking-[0.3em] uppercase text-gold font-medium mb-4">Featured Drop</p>
                <div className="relative overflow-hidden group cursor-pointer" onClick={() => { navigate('/products?badge=new'); closeMegaMenu() }}>
                  <div className="aspect-[4/3] bg-gradient-to-br from-beige to-cream flex items-center justify-center font-display text-5xl text-charcoal/10 group-hover:scale-105 transition-transform duration-500">
                    ✦
                  </div>
                  <p className="mt-3 text-xs tracking-widest uppercase font-medium">Summer Drop 2026</p>
                  <p className="text-xs text-warm-gray mt-1">New arrivals weekly</p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Search Bar */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-[72px] left-0 right-0 bg-white border-b border-beige shadow-lg z-40 px-6 lg:px-10 py-5"
          >
            <div className="max-w-3xl mx-auto">
              <div className="flex items-center gap-4 border-b border-beige pb-3">
                <SearchIcon />
                <input
                  autoFocus
                  type="text"
                  placeholder="Search styles, brands, categories..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="flex-1 text-lg outline-none bg-transparent placeholder:text-warm-gray/60"
                  onKeyDown={e => {
                    if (e.key === 'Enter' && searchQuery) {
                      navigate(`/products?q=${searchQuery}`)
                      toggleSearch()
                      setSearchQuery('')
                    }
                    if (e.key === 'Escape') { toggleSearch(); setSearchQuery('') }
                  }}
                />
                <button onClick={() => { toggleSearch(); setSearchQuery('') }} className="text-warm-gray hover:text-charcoal">✕</button>
              </div>

              {/* Live results */}
              {searchResults.length > 0 && (
                <div className="mt-3 space-y-2">
                  {searchResults.map(p => (
                    <div
                      key={p.id}
                      className="flex items-center gap-4 p-2 hover:bg-cream cursor-pointer rounded transition-colors"
                      onClick={() => { navigate(`/product/${p.id}`); toggleSearch(); setSearchQuery('') }}
                    >
                      <div className="w-10 h-10 bg-beige flex items-center justify-center text-xl flex-shrink-0">{p.emoji}</div>
                      <div>
                        <p className="text-sm font-medium">{p.name}</p>
                        <p className="text-xs text-warm-gray capitalize">{p.category} · ${p.price}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Popular tags */}
              {!searchQuery && (
                <div className="flex items-center gap-2 mt-4 flex-wrap">
                  <span className="text-[11px] text-warm-gray uppercase tracking-widest">Trending:</span>
                  {['Hoodies', 'Sneakers', 'Silk Blouse', 'Bomber', 'Linen Set'].map(tag => (
                    <button
                      key={tag}
                      onClick={() => { navigate(`/products?q=${tag}`); toggleSearch() }}
                      className="text-xs border border-beige px-3 py-1.5 hover:bg-charcoal hover:text-white hover:border-charcoal transition-all uppercase tracking-wide"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: '-100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '-100%' }}
            transition={{ duration: 0.35, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="fixed inset-0 bg-cream z-50 lg:hidden flex flex-col p-8 pt-24"
          >
            <button className="absolute top-6 right-6 text-2xl" onClick={() => setMobileOpen(false)}>✕</button>
            <p className="font-display text-2xl tracking-widest mb-8">VELORA</p>
            <nav className="space-y-6">
              {[...NAV_ITEMS, { label: 'Account', to: user ? '/account' : '/auth' }, { label: 'Wishlist', to: '/wishlist' }].map(item => (
                <Link
                  key={item.label}
                  to={item.to || '/products'}
                  className="block font-display text-2xl font-light text-charcoal hover:text-gold transition-colors"
                  onClick={() => setMobileOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
            <div className="mt-auto">
              <p className="text-xs text-warm-gray tracking-widest uppercase">Free shipping on orders over $200</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
