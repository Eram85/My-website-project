import { useScrollProgress } from '../../hooks'
export default function ScrollProgress() {
  const p = useScrollProgress()
  return <div className="fixed top-0 left-0 h-[2px] bg-gold z-[9999] transition-all duration-100" style={{ width: `${p}%` }} />
}
