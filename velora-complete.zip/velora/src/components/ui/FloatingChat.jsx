import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
export default function FloatingChat() {
  const [open, setOpen] = useState(false)
  const [msg, setMsg] = useState('')
  const [msgs, setMsgs] = useState([{ from:'bot', text:"Hi! Need styling help? I'm here! 👗" }])
  const send = () => {
    if (!msg.trim()) return
    setMsgs(m => [...m, { from:'user', text:msg }, { from:'bot', text:'Thanks for reaching out! Our styling team will reply shortly. Explore our latest collection in the meantime! ✨' }])
    setMsg('')
  }
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3">
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity:0, y:20, scale:0.9 }} animate={{ opacity:1, y:0, scale:1 }} exit={{ opacity:0, y:20, scale:0.9 }}
            className="w-80 bg-white shadow-2xl border border-beige overflow-hidden">
            <div className="bg-charcoal px-4 py-3 flex justify-between items-center">
              <div><p className="text-white text-sm font-medium">VELORA Support</p><p className="text-white/50 text-xs">Typically replies instantly</p></div>
              <button onClick={() => setOpen(false)} className="text-white/60 hover:text-white text-lg">✕</button>
            </div>
            <div className="h-52 overflow-y-auto p-4 space-y-3 bg-cream">
              {msgs.map((m, i) => (
                <div key={i} className={`flex ${m.from==='user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] px-3 py-2 text-sm ${m.from==='user' ? 'bg-charcoal text-white' : 'bg-white border border-beige text-charcoal'}`}>{m.text}</div>
                </div>
              ))}
            </div>
            <div className="flex border-t border-beige">
              <input value={msg} onChange={e=>setMsg(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Type a message..." className="flex-1 px-4 py-3 text-sm outline-none" />
              <button onClick={send} className="px-4 bg-gold text-white text-xs hover:bg-accent transition-colors">Send</button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <motion.button whileHover={{ scale:1.1 }} whileTap={{ scale:0.95 }} onClick={() => setOpen(o=>!o)}
        className="w-14 h-14 bg-gold rounded-full flex items-center justify-center shadow-lg hover:bg-accent transition-colors">
        <svg className="w-6 h-6 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      </motion.button>
    </div>
  )
}
