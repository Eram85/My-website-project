import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { useCartStore, useWishlistStore, useUIStore } from '../../context/useStore'
import { formatPrice } from '../../utils'

export default function ProductCard({ product, index = 0 }) {
  const { addItem, openCart }       = useCartStore()
  const { toggle, isWishlisted }    = useWishlistStore()
  const { openProductModal, addRecentlyViewed } = useUIStore()
  const wishlisted = isWishlisted(product.id)

  const handleAddToCart = e => {
    e.preventDefault(); e.stopPropagation()
    addItem(product, product.sizes?.[1] || product.sizes?.[0], product.colors?.[0] || '')
    toast.success(`${product.name} added to bag ✓`, { icon:'🛍' })
    openCart()
  }

  const handleWishlist = e => {
    e.preventDefault(); e.stopPropagation()
    toggle(product)
    toast.success(wishlisted ? 'Removed from wishlist' : 'Added to wishlist ♥', { icon: wishlisted ? '💔' : '❤️' })
  }

  const handleQuickView = e => {
    e.preventDefault(); e.stopPropagation()
    openProductModal(product)
    addRecentlyViewed(product)
  }

  const pct = product.oldPrice ? Math.round((1 - product.price/product.oldPrice)*100) : 0

  return (
    <motion.div initial={{ opacity:0, y:24 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}
      transition={{ duration:0.5, delay:index*0.07 }} className="group relative bg-white cursor-pointer">
      <Link to={`/product/${product.id}`} onClick={() => addRecentlyViewed(product)}>
        {/* Image */}
        <div className="relative overflow-hidden aspect-[3/4] bg-beige">
          <img src={product.images?.[0]} alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.04]"
            loading="lazy" />

          {/* Badge */}
          {product.badge && (
            <span className={`absolute top-3 left-3 px-2.5 py-1 text-[10px] tracking-widest uppercase font-medium z-10 ${product.badge==='new' ? 'bg-charcoal text-white' : product.badge==='sale' ? 'bg-red-600 text-white' : 'bg-gold text-white'}`}>
              {product.badge==='sale' && pct > 0 ? `-${pct}%` : product.badge}
            </span>
          )}

          {/* Wishlist btn */}
          <button onClick={handleWishlist}
            className="absolute top-3 right-3 w-9 h-9 bg-white/90 rounded-full flex items-center justify-center z-10 opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-rose/20 hover:scale-110">
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill={wishlisted ? '#D4A5A5' : 'none'} stroke={wishlisted ? '#D4A5A5' : 'currentColor'} strokeWidth="1.5">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
          </button>

          {/* Hover actions */}
          <div className="absolute bottom-0 left-0 right-0 flex gap-px translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-[cubic-bezier(0.25,0.46,0.45,0.94)] z-10">
            <button onClick={handleQuickView}
              className="flex-1 py-3 bg-charcoal/90 backdrop-blur-sm text-white text-[10px] tracking-widest uppercase flex items-center justify-center gap-2 hover:bg-gold transition-colors duration-200">
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
              Quick View
            </button>
            <button onClick={handleAddToCart}
              className="flex-1 py-3 bg-charcoal/90 backdrop-blur-sm text-white text-[10px] tracking-widest uppercase hover:bg-gold transition-colors duration-200">
              Add to Bag
            </button>
          </div>
        </div>

        {/* Info */}
        <div className="pt-3 pb-2 px-0.5">
          <p className="text-[10px] tracking-[0.2em] uppercase text-warm-gray mb-1">{product.brand}</p>
          <p className="font-display text-[1.05rem] font-normal text-charcoal leading-snug group-hover:text-gold transition-colors duration-200">{product.name}</p>
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-[15px] font-medium">{formatPrice(product.price)}</span>
            {product.oldPrice && <span className="text-xs text-warm-gray line-through">{formatPrice(product.oldPrice)}</span>}
          </div>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="text-gold text-xs">{'★'.repeat(Math.floor(product.rating))}{'☆'.repeat(5-Math.floor(product.rating))}</span>
            <span className="text-[11px] text-warm-gray">({product.reviews})</span>
          </div>
          {product.colors?.length > 1 && (
            <div className="flex gap-1.5 mt-2">
              {product.colors.slice(0,4).map(c => (
                <div key={c} title={c} className="w-3 h-3 rounded-full border border-beige"
                  style={{ background:{ Black:'#1A1A1A', White:'#FFFFFF', Beige:'#E8E2D9', Gold:'#C9A96E', Navy:'#1A2035', Rose:'#D4A5A5', Burgundy:'#6E1A2A', Olive:'#4A5230' }[c]||'#8C8680' }} />
              ))}
            </div>
          )}
        </div>
      </Link>
    </motion.div>
  )
}
