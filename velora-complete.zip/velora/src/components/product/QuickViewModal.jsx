import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { useUIStore, useCartStore, useWishlistStore } from '../../context/useStore'
import { formatPrice } from '../../utils'

export default function QuickViewModal() {
  const { modalProduct: product, closeProductModal } = useUIStore()
  const { addItem, openCart }      = useCartStore()
  const { toggle, isWishlisted }   = useWishlistStore()
  const [selectedSize,  setSelectedSize]  = useState(null)
  const [selectedColor, setSelectedColor] = useState(null)
  const [qty, setQty] = useState(1)

  if (!product) return null
  const wishlisted = isWishlisted(product.id)
  const colorHex = { Black:'#1A1A1A', White:'#F5F5F5', Beige:'#E8E2D9', Gold:'#C9A96E', Navy:'#1A2035', Rose:'#D4A5A5', Burgundy:'#6E1A2A', Olive:'#4A5230' }

  const handleAddToCart = () => {
    if (!selectedSize && product.sizes?.length > 1) { toast.error('Please select a size'); return }
    for (let i = 0; i < qty; i++) addItem(product, selectedSize || product.sizes?.[0], selectedColor || product.colors?.[0] || '')
    toast.success(`${product.name} added to bag ✓`, { icon:'🛍' })
    openCart(); closeProductModal()
  }

  return (
    <AnimatePresence>
      {product && (
        <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} exit={{ opacity:0 }}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[70] flex items-center justify-center p-4"
          onClick={e => e.target===e.currentTarget && closeProductModal()}>
          <motion.div initial={{ opacity:0, scale:0.96, y:20 }} animate={{ opacity:1, scale:1, y:0 }} exit={{ opacity:0, scale:0.96 }}
            transition={{ duration:0.3 }} className="bg-white w-full max-w-[900px] max-h-[90vh] overflow-y-auto relative">

            <button onClick={closeProductModal} className="absolute top-4 right-4 z-10 w-10 h-10 bg-cream flex items-center justify-center hover:bg-charcoal hover:text-white transition-all">✕</button>

            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Image */}
              <div className="aspect-[3/4] md:aspect-auto overflow-hidden bg-beige min-h-[400px]">
                <img src={product.images?.[0]} alt={product.name} className="w-full h-full object-cover" />
              </div>

              {/* Info */}
              <div className="p-8 flex flex-col">
                <p className="text-[10px] tracking-[0.3em] uppercase text-gold mb-2">{product.brand}</p>
                <h2 className="font-display text-2xl md:text-3xl font-light mb-2 leading-tight">{product.name}</h2>
                <div className="flex items-center gap-3 mb-4">
                  <span className="text-gold text-sm">{'★'.repeat(Math.floor(product.rating))}</span>
                  <span className="text-sm text-warm-gray">({product.reviews} reviews)</span>
                </div>
                <div className="flex items-baseline gap-3 mb-6">
                  <span className="font-display text-2xl">{formatPrice(product.price)}</span>
                  {product.oldPrice && <span className="text-warm-gray line-through text-lg">{formatPrice(product.oldPrice)}</span>}
                </div>

                {/* Colors */}
                {product.colors?.length > 0 && (
                  <div className="mb-5">
                    <p className="text-[10px] tracking-widest uppercase text-warm-gray mb-2">Color: <span className="text-charcoal">{selectedColor || product.colors[0]}</span></p>
                    <div className="flex gap-2">
                      {product.colors.map(c => (
                        <button key={c} title={c} onClick={() => setSelectedColor(c)}
                          className={`w-8 h-8 rounded-full border-2 transition-all hover:scale-110 ${(selectedColor||product.colors[0])===c ? 'border-charcoal' : 'border-transparent'}`}
                          style={{ background:colorHex[c]||'#8C8680', boxShadow:c==='White'?'inset 0 0 0 1px #ddd':'none' }} />
                      ))}
                    </div>
                  </div>
                )}

                {/* Sizes */}
                {product.sizes?.length > 0 && (
                  <div className="mb-5">
                    <p className="text-[10px] tracking-widest uppercase text-warm-gray mb-2">Size: <span className="text-charcoal">{selectedSize || 'Select a size'}</span></p>
                    <div className="flex flex-wrap gap-2">
                      {product.sizes.map(s => (
                        <button key={s} onClick={() => setSelectedSize(s)}
                          className={`min-w-[44px] h-11 px-3 border text-xs font-medium transition-all duration-200 ${selectedSize===s ? 'bg-charcoal text-white border-charcoal' : 'border-beige hover:border-charcoal'}`}>
                          {s}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Qty */}
                <div className="flex items-center gap-4 mb-5">
                  <p className="text-[10px] tracking-widest uppercase text-warm-gray">Qty</p>
                  <div className="flex items-center border border-beige">
                    <button onClick={() => setQty(q => Math.max(1,q-1))} className="w-9 h-9 flex items-center justify-center hover:bg-beige transition-colors">−</button>
                    <span className="w-10 text-center text-sm font-medium">{qty}</span>
                    <button onClick={() => setQty(q => q+1)} className="w-9 h-9 flex items-center justify-center hover:bg-beige transition-colors">+</button>
                  </div>
                </div>

                <div className="space-y-2 mb-5">
                  <button onClick={handleAddToCart} className="w-full py-4 bg-charcoal text-white text-xs tracking-widest uppercase font-medium hover:bg-gold transition-colors duration-300">
                    Add to Bag — {formatPrice(product.price * qty)}
                  </button>
                  <button onClick={() => { toggle(product); toast.success(wishlisted ? 'Removed from wishlist' : 'Added to wishlist ♥') }}
                    className={`w-full py-3.5 border text-xs tracking-widest uppercase flex items-center justify-center gap-2 hover:bg-cream transition-colors ${wishlisted ? 'border-rose bg-rose/10' : 'border-beige'}`}>
                    {wishlisted ? '♥ Wishlisted' : '♡ Save to Wishlist'}
                  </button>
                </div>

                <p className="text-sm text-warm-gray leading-relaxed border-t border-beige pt-4 mb-4">{product.description}</p>
                <div className="grid grid-cols-2 gap-2 mb-4">
                  {['Free shipping','30-day returns','Authenticity guarantee','Secure checkout'].map(t => (
                    <p key={t} className="text-xs text-warm-gray flex items-center gap-2"><span className="text-gold">✓</span>{t}</p>
                  ))}
                </div>
                <Link to={`/product/${product.id}`} onClick={closeProductModal} className="text-xs tracking-widest uppercase text-charcoal underline underline-offset-4 hover:text-gold transition-colors">
                  View Full Details →
                </Link>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
