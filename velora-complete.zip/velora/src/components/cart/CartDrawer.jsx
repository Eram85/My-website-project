// src/components/cart/CartDrawer.jsx
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { useCartStore } from '../../context/useStore'
import { formatPrice } from '../../utils'
import { validateCoupon } from '../../firebase/firestore'

export default function CartDrawer() {
  const {
    isOpen, closeCart, items, removeItem, updateQty,
    subtotal, discountAmount, total, isFreeShipping,
    coupon, applyCoupon, removeCoupon, itemCount,
  } = useCartStore()

  const [couponCode, setCouponCode] = useState('')
  const [couponLoading, setCouponLoading] = useState(false)
  const navigate = useNavigate()

  const handleCoupon = async () => {
    if (!couponCode.trim()) return
    setCouponLoading(true)
    try {
      // Try Firestore first, then fallback to hardcoded
      let found = null
      try {
        found = await validateCoupon(couponCode)
      } catch {
        // Firestore not configured yet — use demo codes
        const DEMO = {
          'VELORA15': { code: 'VELORA15', discount: 15, type: 'percentage' },
          'WELCOME10': { code: 'WELCOME10', discount: 10, type: 'percentage' },
          'FLASH50':   { code: 'FLASH50',   discount: 50, type: 'percentage' },
        }
        found = DEMO[couponCode.toUpperCase()] || null
      }
      if (found) {
        applyCoupon(found)
        toast.success(`${found.discount}% discount applied! 🎉`)
        setCouponCode('')
      } else {
        toast.error('Invalid or expired coupon code')
      }
    } finally {
      setCouponLoading(false)
    }
  }

  const handleCheckout = () => {
    if (!items.length) { toast.error('Your bag is empty'); return }
    closeCart()
    navigate('/checkout')
  }

  return (
    <>
      {/* Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50"
            onClick={closeCart}
          />
        )}
      </AnimatePresence>

      {/* Drawer */}
      <AnimatePresence>
        {isOpen && (
          <motion.aside
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] }}
            className="fixed top-0 right-0 bottom-0 w-full sm:w-[420px] bg-white z-[60] flex flex-col shadow-2xl"
          >
            {/* Header */}
            <div className="px-6 py-5 border-b border-beige flex justify-between items-center">
              <h2 className="font-display text-xl font-light">
                Your Bag <span className="text-sm font-body font-normal text-warm-gray">({itemCount} {itemCount === 1 ? 'item' : 'items'})</span>
              </h2>
              <button
                onClick={closeCart}
                className="w-9 h-9 border border-beige flex items-center justify-center hover:bg-charcoal hover:text-white hover:border-charcoal transition-all duration-200"
                aria-label="Close cart"
              >
                ✕
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
                  <div className="text-6xl opacity-20">🛍</div>
                  <p className="font-display text-xl text-warm-gray">Your bag is empty</p>
                  <p className="text-sm text-warm-gray/70">Add some luxury to your life</p>
                  <button
                    onClick={() => { closeCart(); navigate('/products') }}
                    className="mt-2 px-8 py-3 bg-charcoal text-white text-xs tracking-widest uppercase hover:bg-gold transition-colors"
                  >
                    Explore Collection
                  </button>
                </div>
              ) : (
                <AnimatePresence>
                  {items.map(item => (
                    <motion.div
                      key={item.key}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      exit={{ opacity: 0, x: -20 }}
                      layout
                      className="flex gap-4 py-4 border-b border-beige"
                    >
                      {/* Image */}
                      <div
                        className="w-20 h-24 bg-beige flex-shrink-0 flex items-center justify-center text-3xl cursor-pointer"
                        onClick={() => { closeCart(); navigate(`/product/${item.id}`) }}
                      >
                        {item.emoji}
                      </div>

                      {/* Info */}
                      <div className="flex-1 min-w-0">
                        <p className="text-[10px] tracking-widest uppercase text-warm-gray">{item.brand}</p>
                        <p
                          className="font-display text-base font-normal mt-0.5 cursor-pointer hover:text-gold transition-colors truncate"
                          onClick={() => { closeCart(); navigate(`/product/${item.id}`) }}
                        >
                          {item.name}
                        </p>
                        <p className="text-xs text-warm-gray mt-0.5">Size: {item.size} {item.color ? `· ${item.color}` : ''}</p>

                        <div className="flex items-center justify-between mt-3">
                          {/* Qty */}
                          <div className="flex items-center border border-beige">
                            <button
                              onClick={() => updateQty(item.key, item.qty - 1)}
                              className="w-7 h-7 flex items-center justify-center text-base hover:bg-charcoal hover:text-white transition-colors"
                            >
                              −
                            </button>
                            <span className="w-8 text-center text-sm">{item.qty}</span>
                            <button
                              onClick={() => updateQty(item.key, item.qty + 1)}
                              className="w-7 h-7 flex items-center justify-center text-base hover:bg-charcoal hover:text-white transition-colors"
                            >
                              +
                            </button>
                          </div>
                          <span className="text-sm font-medium">{formatPrice(item.price * item.qty)}</span>
                        </div>

                        <button
                          onClick={() => { removeItem(item.key); toast.success('Item removed') }}
                          className="text-[11px] text-warm-gray hover:text-red-500 uppercase tracking-wider mt-2 transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="px-6 py-5 border-t border-beige bg-cream">
                {/* Coupon */}
                <div className="flex gap-2 mb-4">
                  <input
                    value={couponCode}
                    onChange={e => setCouponCode(e.target.value)}
                    placeholder={coupon ? `Applied: ${coupon.code}` : 'Coupon code...'}
                    disabled={!!coupon}
                    onKeyDown={e => e.key === 'Enter' && handleCoupon()}
                    className="flex-1 border border-beige bg-white px-3 py-2.5 text-sm outline-none focus:border-charcoal transition-colors placeholder:text-warm-gray/60 disabled:opacity-50"
                  />
                  {coupon ? (
                    <button
                      onClick={() => { removeCoupon(); toast.success('Coupon removed') }}
                      className="px-4 bg-charcoal text-white text-xs tracking-widest uppercase hover:bg-red-600 transition-colors"
                    >
                      Remove
                    </button>
                  ) : (
                    <button
                      onClick={handleCoupon}
                      disabled={couponLoading}
                      className="px-4 bg-charcoal text-white text-xs tracking-widest uppercase hover:bg-gold transition-colors disabled:opacity-50"
                    >
                      {couponLoading ? '...' : 'Apply'}
                    </button>
                  )}
                </div>

                {/* Totals */}
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm text-warm-gray">
                    <span>Subtotal</span><span>{formatPrice(subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm text-warm-gray">
                    <span>Shipping</span>
                    <span className={isFreeShipping ? 'text-green-600 font-medium' : ''}>
                      {isFreeShipping ? 'Free' : formatPrice(15)}
                    </span>
                  </div>
                  {discountAmount > 0 && (
                    <div className="flex justify-between text-sm text-green-600">
                      <span>Discount ({coupon?.discount}%)</span>
                      <span>−{formatPrice(discountAmount)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-base font-medium border-t border-beige pt-3 mt-2">
                    <span>Total</span><span>{formatPrice(total + (isFreeShipping ? 0 : 15))}</span>
                  </div>
                </div>

                {!isFreeShipping && (
                  <p className="text-xs text-warm-gray mb-3 text-center">
                    Add {formatPrice(200 - subtotal)} more for free shipping
                  </p>
                )}

                <button
                  onClick={handleCheckout}
                  className="w-full py-4 bg-charcoal text-white text-xs tracking-widest uppercase font-medium hover:bg-gold transition-colors duration-300"
                >
                  Proceed to Checkout →
                </button>

                <button
                  onClick={() => { closeCart(); navigate('/products') }}
                  className="w-full py-2 mt-2 text-xs text-warm-gray tracking-widest uppercase hover:text-charcoal transition-colors text-center"
                >
                  Continue Shopping
                </button>
              </div>
            )}
          </motion.aside>
        )}
      </AnimatePresence>
    </>
  )
}
