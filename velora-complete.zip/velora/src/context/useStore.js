// src/context/useStore.js
// Global state management with Zustand
import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'

// ── CART STORE ────────────────────────────────────────────────
export const useCartStore = create(
  persist(
    (set, get) => ({
      items: [],
      isOpen: false,
      coupon: null,
      discount: 0,

      openCart:  () => set({ isOpen: true }),
      closeCart: () => set({ isOpen: false }),
      toggleCart: () => set(s => ({ isOpen: !s.isOpen })),

      addItem: (product, size, color) => {
        const { items } = get()
        const key = `${product.id}-${size}-${color}`
        const existing = items.find(i => i.key === key)
        if (existing) {
          set({ items: items.map(i => i.key === key ? { ...i, qty: i.qty + 1 } : i) })
        } else {
          set({ items: [...items, { ...product, key, size, color, qty: 1 }] })
        }
      },

      removeItem: (key) =>
        set(s => ({ items: s.items.filter(i => i.key !== key) })),

      updateQty: (key, qty) => {
        if (qty < 1) { get().removeItem(key); return }
        set(s => ({ items: s.items.map(i => i.key === key ? { ...i, qty } : i) }))
      },

      clearCart: () => set({ items: [], coupon: null, discount: 0 }),

      applyCoupon: (coupon) => {
        set({
          coupon,
          discount: coupon.type === 'percentage' ? coupon.discount : 0,
        })
      },

      removeCoupon: () => set({ coupon: null, discount: 0 }),

      get subtotal() {
        return get().items.reduce((sum, i) => sum + i.price * i.qty, 0)
      },

      get discountAmount() {
        const { discount } = get()
        return (get().subtotal * discount) / 100
      },

      get total() {
        return get().subtotal - get().discountAmount
      },

      get itemCount() {
        return get().items.reduce((sum, i) => sum + i.qty, 0)
      },

      get isFreeShipping() {
        return get().subtotal >= 200 || get().coupon?.type === 'freeshipping'
      },
    }),
    {
      name: 'velora-cart',
      storage: createJSONStorage(() => localStorage),
    }
  )
)

// ── WISHLIST STORE ────────────────────────────────────────────
export const useWishlistStore = create(
  persist(
    (set, get) => ({
      items: [],

      addItem: (product) => {
        if (!get().items.find(i => i.id === product.id)) {
          set(s => ({ items: [...s.items, product] }))
        }
      },

      removeItem: (id) =>
        set(s => ({ items: s.items.filter(i => i.id !== id) })),

      toggle: (product) => {
        if (get().isWishlisted(product.id)) {
          get().removeItem(product.id)
        } else {
          get().addItem(product)
        }
      },

      isWishlisted: (id) => get().items.some(i => i.id === id),
      count: () => get().items.length,
    }),
    {
      name: 'velora-wishlist',
      storage: createJSONStorage(() => localStorage),
    }
  )
)

// ── UI STORE ─────────────────────────────────────────────────
export const useUIStore = create((set) => ({
  searchOpen:   false,
  megaMenuOpen: false,
  modalProduct: null,
  darkMode:     false,
  currency:     'USD',
  language:     'en',
  recentlyViewed: [],

  toggleSearch:  () => set(s => ({ searchOpen: !s.searchOpen })),
  closeSearch:   () => set({ searchOpen: false }),
  openMegaMenu:  () => set({ megaMenuOpen: true }),
  closeMegaMenu: () => set({ megaMenuOpen: false }),

  openProductModal:  (product) => set({ modalProduct: product }),
  closeProductModal: () => set({ modalProduct: null }),

  toggleDarkMode: () => {
    set(s => {
      const next = !s.darkMode
      document.documentElement.classList.toggle('dark', next)
      return { darkMode: next }
    })
  },

  setCurrency: (currency) => set({ currency }),
  setLanguage: (language) => set({ language }),

  addRecentlyViewed: (product) => set(s => {
    const list = [product, ...s.recentlyViewed.filter(p => p.id !== product.id)].slice(0, 10)
    return { recentlyViewed: list }
  }),
}))
