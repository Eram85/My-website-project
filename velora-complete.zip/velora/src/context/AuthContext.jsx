import { createContext, useContext, useEffect, useState } from 'react'
import { onAuthChange, getUserRole } from '../firebase/auth'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [user,    setUser]    = useState(null)
  const [role,    setRole]    = useState('customer')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let unsub = () => {}
    try {
      unsub = onAuthChange(async firebaseUser => {
        if (firebaseUser) {
          const r = await getUserRole(firebaseUser.uid)
          setRole(r || 'customer')
          setUser(firebaseUser)
        } else {
          setUser(null)
          setRole('customer')
        }
        setLoading(false)
      })
    } catch {
      setLoading(false)
    }
    return unsub
  }, [])

  return (
    <AuthContext.Provider value={{ user, role, loading, isAdmin: role === 'admin' }}>
      {children}
    </AuthContext.Provider>
  )
}

export const useAuth = () => {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be inside AuthProvider')
  return ctx
}
