import {
  collection, doc, getDocs, getDoc, addDoc, updateDoc,
  deleteDoc, query, where, orderBy, limit, serverTimestamp,
  increment, arrayUnion, arrayRemove, onSnapshot
} from 'firebase/firestore'
import { db } from './config'

const safe = async (fn, fallback = null) => { try { return await fn() } catch { return fallback } }

export const getProducts = (filters={}) => safe(async () => {
  let q = collection(db, 'products')
  const c = []
  if (filters.category) c.push(where('category','==',filters.category))
  if (filters.featured) c.push(where('featured','==',true))
  c.push(orderBy('createdAt','desc'))
  if (filters.limit)    c.push(limit(filters.limit))
  const snap = await getDocs(query(q, ...c))
  return snap.docs.map(d => ({ id:d.id, ...d.data() }))
}, [])

export const getProduct = id => safe(async () => {
  const snap = await getDoc(doc(db,'products',id))
  return snap.exists() ? { id:snap.id, ...snap.data() } : null
})

export const addProduct    = data  => safe(() => addDoc(collection(db,'products'), { ...data, createdAt:serverTimestamp(), views:0 }))
export const updateProduct = (id,d)=> safe(() => updateDoc(doc(db,'products',id), { ...d, updatedAt:serverTimestamp() }))
export const deleteProduct = id    => safe(() => deleteDoc(doc(db,'products',id)))

export const createOrder = data => safe(() => addDoc(collection(db,'orders'), { ...data, status:'pending', createdAt:serverTimestamp() }))
export const getUserOrders = uid => safe(async () => {
  const q = query(collection(db,'orders'), where('userId','==',uid), orderBy('createdAt','desc'))
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id:d.id, ...d.data() }))
}, [])
export const getAllOrders = () => safe(async () => {
  const snap = await getDocs(query(collection(db,'orders'), orderBy('createdAt','desc')))
  return snap.docs.map(d => ({ id:d.id, ...d.data() }))
}, [])
export const updateOrderStatus = (id,status) => safe(() => updateDoc(doc(db,'orders',id), { status, updatedAt:serverTimestamp() }))

export const addReview = data => safe(() => addDoc(collection(db,'reviews'), { ...data, createdAt:serverTimestamp(), helpful:0 }))
export const getProductReviews = productId => safe(async () => {
  const q = query(collection(db,'reviews'), where('productId','==',productId), orderBy('createdAt','desc'))
  const snap = await getDocs(q)
  return snap.docs.map(d => ({ id:d.id, ...d.data() }))
}, [])

export const getUser = uid => safe(async () => {
  const snap = await getDoc(doc(db,'users',uid))
  return snap.exists() ? { id:snap.id, ...snap.data() } : null
})
export const updateUser = (uid, data) => safe(() => updateDoc(doc(db,'users',uid), { ...data, updatedAt:serverTimestamp() }))
export const addToWishlist    = (uid,pid) => safe(() => updateDoc(doc(db,'users',uid), { wishlist:arrayUnion(pid) }))
export const removeFromWishlist=(uid,pid) => safe(() => updateDoc(doc(db,'users',uid), { wishlist:arrayRemove(pid) }))

export const validateCoupon = async code => {
  return safe(async () => {
    const q = query(collection(db,'coupons'), where('code','==',code.toUpperCase()), where('active','==',true))
    const snap = await getDocs(q)
    if (snap.empty) return null
    const coupon = { id:snap.docs[0].id, ...snap.docs[0].data() }
    if (coupon.expiresAt && coupon.expiresAt.toDate() < new Date()) return null
    return coupon
  })
}
