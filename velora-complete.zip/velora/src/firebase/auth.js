import {
  signInWithEmailAndPassword, createUserWithEmailAndPassword,
  signInWithPopup, signOut, sendPasswordResetEmail,
  updateProfile, onAuthStateChanged
} from 'firebase/auth'
import { doc, setDoc, getDoc, serverTimestamp } from 'firebase/firestore'
import { auth, googleProvider, db } from './config'

export const signUp = async (email, password, displayName) => {
  const cred = await createUserWithEmailAndPassword(auth, email, password)
  await updateProfile(cred.user, { displayName })
  try {
    await setDoc(doc(db, 'users', cred.user.uid), {
      uid: cred.user.uid, email, displayName,
      role:'customer', wishlist:[], addresses:[],
      createdAt: serverTimestamp()
    })
  } catch {}
  return cred.user
}

export const signIn = async (email, password) => {
  const cred = await signInWithEmailAndPassword(auth, email, password)
  return cred.user
}

export const signInWithGoogle = async () => {
  const cred = await signInWithPopup(auth, googleProvider)
  try {
    const userDoc = await getDoc(doc(db, 'users', cred.user.uid))
    if (!userDoc.exists()) {
      await setDoc(doc(db, 'users', cred.user.uid), {
        uid: cred.user.uid, email: cred.user.email,
        displayName: cred.user.displayName, photoURL: cred.user.photoURL,
        role:'customer', wishlist:[], addresses:[], createdAt: serverTimestamp()
      })
    }
  } catch {}
  return cred.user
}

export const logOut = () => signOut(auth)
export const resetPassword = email => sendPasswordResetEmail(auth, email)
export const onAuthChange  = cb => onAuthStateChanged(auth, cb)

export const getUserRole = async uid => {
  try {
    const snap = await getDoc(doc(db, 'users', uid))
    return snap.exists() ? snap.data().role : 'customer'
  } catch { return 'customer' }
}
