import { useState } from 'react'
import { motion } from 'framer-motion'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts'
import { PRODUCTS } from '../data/products'
import { formatPrice } from '../utils'

const SALES = [
  { month:'Jan', revenue:28000, orders:142 }, { month:'Feb', revenue:35000, orders:178 },
  { month:'Mar', revenue:42000, orders:210 }, { month:'Apr', revenue:38000, orders:195 },
  { month:'May', revenue:51000, orders:258 }, { month:'Jun', revenue:63000, orders:318 },
]
const CAT_DATA = [
  { name:'Women', value:38 }, { name:'Men', value:24 }, { name:'Streetwear', value:18 },
  { name:'Sneakers', value:12 }, { name:'Accessories', value:8 },
]
const COLORS = ['#C9A96E','#1A1A1A','#8C8680','#E8E2D9','#D4A5A5']
const ORDERS = [
  { id:'VLR-A1B2', customer:'Sophia Laurent', amount:614, status:'delivered', date:'2026-05-14' },
  { id:'VLR-C3D4', customer:'Marcus Chen',    amount:265, status:'shipped',   date:'2026-05-13' },
  { id:'VLR-E5F6', customer:'Aisha Okonkwo',  amount:420, status:'processing',date:'2026-05-13' },
  { id:'VLR-G7H8', customer:'James Park',     amount:189, status:'pending',   date:'2026-05-12' },
  { id:'VLR-I9J0', customer:'Emma Wilson',    amount:895, status:'delivered', date:'2026-05-11' },
]
const STATUS_STYLE = { delivered:'bg-green-100 text-green-700', shipped:'bg-blue-100 text-blue-700', processing:'bg-yellow-100 text-yellow-700', pending:'bg-red-100 text-red-700' }

export default function AdminDashboard() {
  const [tab, setTab] = useState('overview')
  const [editingProduct, setEditingProduct] = useState(null)
  const [products, setProducts] = useState(PRODUCTS)
  const [newProd, setNewProd] = useState({ name:'', price:'', category:'women', badge:'new' })

  const TABS = ['overview','products','orders','customers','settings']

  const STATS = [
    { label:'Total Revenue',  value:'$257,000', change:'+18%', up:true },
    { label:'Total Orders',   value:'1,301',    change:'+12%', up:true },
    { label:'Active Products',value:products.length, change:'+3',   up:true },
    { label:'Avg Order Value', value:'$198',     change:'+5%',  up:true },
  ]

  return (
    <div className="min-h-screen bg-[#0F0F0F] pt-[72px] text-white">
      <div className="flex">
        {/* Sidebar */}
        <aside className="w-56 min-h-screen bg-[#1A1A1A] border-r border-white/10 fixed top-[72px] left-0 bottom-0 p-4">
          <p className="text-[10px] tracking-[0.3em] uppercase text-white/30 mb-4 px-2">Admin Panel</p>
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)}
              className={`w-full text-left px-4 py-2.5 rounded text-sm capitalize mb-1 transition-all ${tab===t ? 'bg-gold text-white' : 'text-white/50 hover:text-white hover:bg-white/5'}`}>
              {t}
            </button>
          ))}
        </aside>

        {/* Main */}
        <main className="flex-1 ml-56 p-8">
          {tab === 'overview' && (
            <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
              <h1 className="font-display text-3xl font-light mb-8">Dashboard Overview</h1>

              {/* Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                {STATS.map(s => (
                  <div key={s.label} className="bg-[#1A1A1A] border border-white/10 p-5">
                    <p className="text-[10px] tracking-widest uppercase text-white/40 mb-2">{s.label}</p>
                    <p className="font-display text-3xl font-light text-white">{s.value}</p>
                    <p className={`text-xs mt-1 ${s.up ? 'text-green-400' : 'text-red-400'}`}>{s.change} vs last month</p>
                  </div>
                ))}
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
                <div className="lg:col-span-2 bg-[#1A1A1A] border border-white/10 p-5">
                  <p className="text-sm text-white/60 mb-4">Monthly Revenue</p>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={SALES}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="month" tick={{ fill:'rgba(255,255,255,0.4)', fontSize:11 }} />
                      <YAxis tick={{ fill:'rgba(255,255,255,0.4)', fontSize:11 }} />
                      <Tooltip contentStyle={{ background:'#1A1A1A', border:'1px solid rgba(255,255,255,0.1)', color:'#fff' }} />
                      <Bar dataKey="revenue" fill="#C9A96E" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <div className="bg-[#1A1A1A] border border-white/10 p-5">
                  <p className="text-sm text-white/60 mb-4">Sales by Category</p>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart><Pie data={CAT_DATA} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({name,value}) => `${name} ${value}%`} labelLine={false} fontSize={10}>
                      {CAT_DATA.map((_,i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie></PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Recent orders */}
              <div className="bg-[#1A1A1A] border border-white/10 p-5">
                <p className="text-sm text-white/60 mb-4">Recent Orders</p>
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-[10px] tracking-widest uppercase text-white/30 border-b border-white/10">
                    {['Order ID','Customer','Amount','Status','Date'].map(h => <th key={h} className="pb-3 pr-4">{h}</th>)}
                  </tr></thead>
                  <tbody className="divide-y divide-white/5">
                    {ORDERS.map(o => (
                      <tr key={o.id}>
                        <td className="py-3 pr-4 font-mono text-xs text-white/60">{o.id}</td>
                        <td className="py-3 pr-4">{o.customer}</td>
                        <td className="py-3 pr-4 font-medium">{formatPrice(o.amount)}</td>
                        <td className="py-3 pr-4"><span className={`text-[10px] px-2 py-1 uppercase tracking-wider font-medium ${STATUS_STYLE[o.status]}`}>{o.status}</span></td>
                        <td className="py-3 text-white/40 text-xs">{o.date}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {tab === 'products' && (
            <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
              <div className="flex items-center justify-between mb-6">
                <h1 className="font-display text-3xl font-light">Products ({products.length})</h1>
                <button onClick={() => setEditingProduct('new')} className="bg-gold text-white px-5 py-2.5 text-xs tracking-widest uppercase hover:bg-accent transition-colors">+ Add Product</button>
              </div>
              <div className="bg-[#1A1A1A] border border-white/10 overflow-hidden">
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-[10px] tracking-widest uppercase text-white/30 border-b border-white/10">
                    {['Product','Category','Price','Stock','Badge','Actions'].map(h => <th key={h} className="p-4">{h}</th>)}
                  </tr></thead>
                  <tbody className="divide-y divide-white/5">
                    {products.map(p => (
                      <tr key={p.id} className="hover:bg-white/3 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <img src={p.images?.[0]} alt={p.name} className="w-10 h-12 object-cover bg-beige flex-shrink-0" />
                            <div><p className="font-medium text-sm">{p.name}</p><p className="text-xs text-white/40">{p.sku}</p></div>
                          </div>
                        </td>
                        <td className="p-4 capitalize text-white/60">{p.category}</td>
                        <td className="p-4 font-medium">{formatPrice(p.price)}</td>
                        <td className="p-4"><span className={`text-[10px] px-2 py-1 ${p.inStock ? 'bg-green-900/40 text-green-400' : 'bg-red-900/40 text-red-400'}`}>{p.inStock ? 'In Stock' : 'Out'}</span></td>
                        <td className="p-4">{p.badge ? <span className="text-[10px] bg-gold/20 text-gold px-2 py-1 uppercase">{p.badge}</span> : '—'}</td>
                        <td className="p-4">
                          <div className="flex gap-2">
                            <button onClick={() => setEditingProduct(p)} className="text-xs text-white/40 hover:text-gold transition-colors">Edit</button>
                            <button onClick={() => { setProducts(prev => prev.filter(x => x.id !== p.id)); }} className="text-xs text-white/40 hover:text-red-400 transition-colors">Delete</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {tab === 'orders' && (
            <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
              <h1 className="font-display text-3xl font-light mb-6">Orders</h1>
              <div className="bg-[#1A1A1A] border border-white/10 overflow-hidden">
                <table className="w-full text-sm">
                  <thead><tr className="text-left text-[10px] tracking-widest uppercase text-white/30 border-b border-white/10">
                    {['Order ID','Customer','Amount','Status','Date','Action'].map(h => <th key={h} className="p-4">{h}</th>)}
                  </tr></thead>
                  <tbody className="divide-y divide-white/5">
                    {ORDERS.map(o => (
                      <tr key={o.id} className="hover:bg-white/3 transition-colors">
                        <td className="p-4 font-mono text-xs text-white/60">{o.id}</td>
                        <td className="p-4">{o.customer}</td>
                        <td className="p-4 font-medium">{formatPrice(o.amount)}</td>
                        <td className="p-4"><span className={`text-[10px] px-2 py-1 uppercase tracking-wider font-medium ${STATUS_STYLE[o.status]}`}>{o.status}</span></td>
                        <td className="p-4 text-white/40 text-xs">{o.date}</td>
                        <td className="p-4">
                          <select className="bg-[#252525] border border-white/10 text-xs px-2 py-1 outline-none text-white/60">
                            {['pending','processing','shipped','delivered'].map(s => <option key={s} selected={s===o.status}>{s}</option>)}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {tab === 'customers' && (
            <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
              <h1 className="font-display text-3xl font-light mb-6">Customers</h1>
              <div className="grid grid-cols-3 gap-4 mb-8">
                {[{l:'Total Customers',v:'12,483'},{l:'New This Month',v:'342'},{l:'Avg Lifetime Value',v:'$890'}].map(s => (
                  <div key={s.l} className="bg-[#1A1A1A] border border-white/10 p-5">
                    <p className="text-[10px] tracking-widest uppercase text-white/40 mb-2">{s.l}</p>
                    <p className="font-display text-3xl font-light">{s.v}</p>
                  </div>
                ))}
              </div>
              <div className="bg-[#1A1A1A] border border-white/10 p-5">
                <p className="text-sm text-white/40 text-center py-8">Connect Firebase to load real customer data</p>
              </div>
            </motion.div>
          )}

          {tab === 'settings' && (
            <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} className="max-w-lg">
              <h1 className="font-display text-3xl font-light mb-6">Settings</h1>
              {[{l:'Store Name',v:'VELORA'},{l:'Currency',v:'USD'},{l:'Tax Rate (%)',v:'0'},{l:'Free Shipping Threshold ($)',v:'200'}].map(s => (
                <div key={s.l} className="bg-[#1A1A1A] border border-white/10 p-5 mb-3">
                  <label className="block text-[10px] tracking-widest uppercase text-white/30 mb-2">{s.l}</label>
                  <input defaultValue={s.v} className="w-full bg-[#252525] border border-white/10 px-4 py-2.5 text-sm text-white outline-none focus:border-gold/50 transition-colors" />
                </div>
              ))}
              <button className="w-full py-3.5 bg-gold text-white text-[11px] tracking-widest uppercase hover:bg-accent transition-colors mt-2">Save Settings</button>
            </motion.div>
          )}
        </main>
      </div>
    </div>
  )
}
