// src/pages/Products.jsx
import { useState, useMemo } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import ProductCard from '../components/product/ProductCard'
import { PRODUCTS, CATEGORIES, COLORS } from '../data/products'

const SORT_OPTIONS = [
  { value:'featured',  label:'Featured' },
  { value:'newest',    label:'Newest' },
  { value:'price-asc', label:'Price: Low to High' },
  { value:'price-desc',label:'Price: High to Low' },
  { value:'rating',    label:'Top Rated' },
]

export default function Products() {
  const [params] = useSearchParams()
  const [sort,     setSort]    = useState('featured')
  const [sideOpen, setSideOpen]= useState(true)
  const [view,     setView]    = useState('grid')
  const [filters,  setFilters] = useState({ categories:[], priceMin:0, priceMax:1000, colors:[], rating:0 })

  const q     = params.get('q')     || ''
  const badge = params.get('badge') || ''
  const sale  = params.get('sale')  || ''
  const cat   = params.get('category') || ''

  const filtered = useMemo(() => {
    let list = [...PRODUCTS]
    if (q)     list = list.filter(p => p.name.toLowerCase().includes(q.toLowerCase()) || p.tags?.some(t => t.includes(q.toLowerCase())))
    if (badge) list = list.filter(p => p.badge === badge)
    if (sale)  list = list.filter(p => !!p.oldPrice)
    const cats = filters.categories.length ? filters.categories : cat ? [cat] : []
    if (cats.length) list = list.filter(p => cats.includes(p.category))
    if (filters.colors.length) list = list.filter(p => p.colors?.some(c => filters.colors.includes(c)))
    if (filters.rating > 0)    list = list.filter(p => p.rating >= filters.rating)
    list = list.filter(p => p.price >= filters.priceMin && p.price <= filters.priceMax)
    if (sort === 'price-asc')  list.sort((a,b) => a.price - b.price)
    if (sort === 'price-desc') list.sort((a,b) => b.price - a.price)
    if (sort === 'rating')     list.sort((a,b) => b.rating - a.rating)
    if (sort === 'newest')     list.sort((a,b) => b.id > a.id ? 1 : -1)
    return list
  }, [q, badge, sale, cat, filters, sort])

  const toggleCategory = id => setFilters(f => ({
    ...f, categories: f.categories.includes(id) ? f.categories.filter(c=>c!==id) : [...f.categories, id]
  }))
  const toggleColor = name => setFilters(f => ({
    ...f, colors: f.colors.includes(name) ? f.colors.filter(c=>c!==name) : [...f.colors, name]
  }))
  const clearFilters = () => setFilters({ categories:[], priceMin:0, priceMax:1000, colors:[], rating:0 })

  const activeCount = filters.categories.length + filters.colors.length + (filters.rating > 0 ? 1 : 0)

  const pageTitle = q ? `Search: "${q}"` : badge === 'new' ? 'New Arrivals' : sale ? 'Sale' : cat ? CATEGORIES.find(c=>c.id===cat)?.label || 'Shop' : 'Shop All'

  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      {/* Page header */}
      <div className="bg-white border-b border-beige">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-8">
          <nav className="flex items-center gap-2 text-xs text-warm-gray mb-3">
            <Link to="/" className="hover:text-charcoal transition-colors">Home</Link>
            <span>/</span>
            <span className="text-charcoal capitalize">{pageTitle}</span>
          </nav>
          <h1 className="font-display text-3xl lg:text-4xl font-light">{pageTitle}</h1>
          <p className="text-sm text-warm-gray mt-2">{filtered.length} products</p>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-8">
        {/* Controls */}
        <div className="flex items-center justify-between mb-8 gap-4 flex-wrap">
          <div className="flex items-center gap-3 flex-wrap">
            <button onClick={() => setSideOpen(o=>!o)}
              className="flex items-center gap-2 border border-beige px-4 py-2.5 text-[11px] tracking-widest uppercase hover:bg-charcoal hover:text-white transition-all">
              <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
                <line x1="4" y1="6" x2="20" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="20" y2="18"/>
              </svg>
              Filters {activeCount > 0 && <span className="w-5 h-5 bg-gold text-white rounded-full text-[9px] flex items-center justify-center">{activeCount}</span>}
            </button>
            {activeCount > 0 && (
              <button onClick={clearFilters} className="text-xs text-warm-gray hover:text-charcoal underline">Clear all</button>
            )}
            {filters.categories.map(c => (
              <span key={c} className="flex items-center gap-1 bg-charcoal text-white text-[10px] tracking-wider uppercase px-3 py-1.5">
                {c}<button onClick={() => toggleCategory(c)} className="ml-1 hover:text-gold">✕</button>
              </span>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex gap-1">
              {['grid','list'].map(v => (
                <button key={v} onClick={() => setView(v)}
                  className={`w-9 h-9 flex items-center justify-center border transition-all ${view===v ? 'bg-charcoal text-white border-charcoal' : 'border-beige hover:border-charcoal'}`}>
                  {v === 'grid'
                    ? <svg className="w-4 h-4" viewBox="0 0 16 16" fill="currentColor"><rect x="0" y="0" width="7" height="7"/><rect x="9" y="0" width="7" height="7"/><rect x="0" y="9" width="7" height="7"/><rect x="9" y="9" width="7" height="7"/></svg>
                    : <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
                  }
                </button>
              ))}
            </div>
            <select value={sort} onChange={e => setSort(e.target.value)}
              className="border border-beige px-4 py-2.5 text-sm bg-white outline-none focus:border-charcoal cursor-pointer">
              {SORT_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>
        </div>

        <div className="flex gap-8">
          {/* Sidebar */}
          <AnimatePresence>
            {sideOpen && (
              <motion.aside initial={{ opacity:0, width:0 }} animate={{ opacity:1, width:260 }} exit={{ opacity:0, width:0 }}
                transition={{ duration:0.3 }} className="flex-shrink-0 overflow-hidden">
                <div className="w-[260px] space-y-8">

                  {/* Categories */}
                  <div>
                    <p className="text-[10px] tracking-[0.3em] uppercase text-warm-gray mb-4 font-medium">Categories</p>
                    <div className="space-y-2">
                      {CATEGORIES.map(c => (
                        <label key={c.id} className="flex items-center gap-3 cursor-pointer group">
                          <input type="checkbox" checked={filters.categories.includes(c.id) || cat===c.id}
                            onChange={() => toggleCategory(c.id)} className="accent-[#C9A96E] w-4 h-4" />
                          <span className="text-sm text-charcoal group-hover:text-gold transition-colors">{c.label}</span>
                          <span className="text-xs text-warm-gray ml-auto">{PRODUCTS.filter(p=>p.category===c.id).length}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Price */}
                  <div>
                    <p className="text-[10px] tracking-[0.3em] uppercase text-warm-gray mb-4 font-medium">Price Range</p>
                    <div className="flex items-center gap-3 mb-3">
                      <input type="number" value={filters.priceMin} onChange={e => setFilters(f=>({...f,priceMin:+e.target.value}))}
                        className="w-20 border border-beige px-3 py-2 text-sm outline-none focus:border-charcoal" placeholder="Min" />
                      <span className="text-warm-gray">—</span>
                      <input type="number" value={filters.priceMax} onChange={e => setFilters(f=>({...f,priceMax:+e.target.value}))}
                        className="w-20 border border-beige px-3 py-2 text-sm outline-none focus:border-charcoal" placeholder="Max" />
                    </div>
                    <input type="range" min={0} max={1000} step={25} value={filters.priceMax}
                      onChange={e => setFilters(f=>({...f,priceMax:+e.target.value}))} className="w-full accent-[#C9A96E]" />
                    <p className="text-xs text-warm-gray mt-1">${filters.priceMin} – ${filters.priceMax}</p>
                  </div>

                  {/* Colors */}
                  <div>
                    <p className="text-[10px] tracking-[0.3em] uppercase text-warm-gray mb-4 font-medium">Color</p>
                    <div className="flex flex-wrap gap-2">
                      {COLORS.map(c => (
                        <button key={c.name} title={c.name} onClick={() => toggleColor(c.name)}
                          className={`w-8 h-8 rounded-full border-2 transition-all ${filters.colors.includes(c.name) ? 'border-charcoal scale-110' : 'border-transparent hover:scale-105'}`}
                          style={{ background:c.hex, boxShadow:c.name==='White'?'inset 0 0 0 1px #ddd':'none' }} />
                      ))}
                    </div>
                  </div>

                  {/* Rating */}
                  <div>
                    <p className="text-[10px] tracking-[0.3em] uppercase text-warm-gray mb-4 font-medium">Min Rating</p>
                    <div className="space-y-2">
                      {[4,3,2].map(r => (
                        <label key={r} className="flex items-center gap-2 cursor-pointer">
                          <input type="radio" name="rating" checked={filters.rating===r}
                            onChange={() => setFilters(f=>({...f, rating: f.rating===r ? 0 : r}))} className="accent-[#C9A96E]" />
                          <span className="text-gold text-sm">{'★'.repeat(r)}{'☆'.repeat(5-r)}</span>
                          <span className="text-xs text-warm-gray">& above</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.aside>
            )}
          </AnimatePresence>

          {/* Grid */}
          <div className="flex-1 min-w-0">
            {filtered.length === 0 ? (
              <div className="text-center py-24">
                <p className="font-display text-3xl font-light text-warm-gray mb-3">No products found</p>
                <p className="text-sm text-warm-gray mb-6">Try adjusting your filters</p>
                <button onClick={clearFilters} className="border border-charcoal px-8 py-3 text-sm uppercase tracking-widest hover:bg-charcoal hover:text-white transition-all">Clear Filters</button>
              </div>
            ) : view === 'grid' ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-10">
                {filtered.map((p,i) => <ProductCard key={p.id} product={p} index={i} />)}
              </div>
            ) : (
              <div className="flex flex-col gap-4">
                {filtered.map((p,i) => (
                  <motion.div key={p.id} initial={{ opacity:0, y:10 }} animate={{ opacity:1, y:0 }} transition={{ delay:i*0.04 }}
                    className="flex gap-6 bg-white p-5 group cursor-pointer border border-beige hover:border-charcoal transition-colors">
                    <Link to={`/product/${p.id}`} className="w-32 h-40 flex-shrink-0 overflow-hidden">
                      <img src={p.images?.[0]} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </Link>
                    <div className="flex-1">
                      <p className="text-[10px] tracking-widest uppercase text-warm-gray mb-1">{p.brand}</p>
                      <Link to={`/product/${p.id}`}><h3 className="font-display text-xl font-light mb-2 hover:text-gold transition-colors">{p.name}</h3></Link>
                      <p className="text-sm text-warm-gray leading-relaxed mb-3 max-w-lg line-clamp-2">{p.description}</p>
                      <div className="flex items-center gap-4">
                        <span className="font-medium">${p.price}</span>
                        {p.oldPrice && <span className="text-sm text-warm-gray line-through">${p.oldPrice}</span>}
                        <span className="text-gold text-sm">{'★'.repeat(Math.round(p.rating))}</span>
                        <span className="text-xs text-warm-gray">({p.reviews})</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
