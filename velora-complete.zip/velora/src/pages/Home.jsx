import { useState, useEffect } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import toast from 'react-hot-toast'
import ProductCard from '../components/product/ProductCard'
import { useCountdown } from '../hooks'
import { PRODUCTS, CATEGORIES, HERO_SLIDES, LOOKBOOK_ITEMS, GALLERY_IMAGES, TESTIMONIALS } from '../data/products'
import { isValidEmail } from '../utils'

// ─── Ticker ──────────────────────────────────────────────────
function Ticker() {
  const items = ['Free Shipping Over $200','New Arrivals Weekly','Summer 2026 Drop is Live','Use Code VELORA15 for 15% Off','Express Delivery Available','Luxury Fashion Curated Daily']
  return (
    <div className="bg-gold py-2.5 overflow-hidden">
      <div className="ticker-animate flex whitespace-nowrap">
        {[...items,...items].map((item,i) => <span key={i} className="text-[11px] tracking-[0.25em] uppercase text-white font-medium px-10">✦ {item}</span>)}
      </div>
    </div>
  )
}

// ─── Hero ────────────────────────────────────────────────────
function Hero() {
  const [current, setCurrent] = useState(0)
  const navigate = useNavigate()
  useEffect(() => {
    const id = setInterval(() => setCurrent(c => (c+1) % HERO_SLIDES.length), 5500)
    return () => clearInterval(id)
  }, [])
  const slide = HERO_SLIDES[current]
  return (
    <section className="relative h-screen min-h-[600px] flex items-center overflow-hidden">
      <AnimatePresence mode="wait">
        <motion.img key={current} src={slide.image} alt={slide.tag}
          initial={{ opacity:0, scale:1.05 }} animate={{ opacity:1, scale:1 }} exit={{ opacity:0 }}
          transition={{ duration:1.2 }} className="absolute inset-0 w-full h-full object-cover" />
      </AnimatePresence>
      <div className="absolute inset-0 bg-gradient-to-r from-black/65 via-black/30 to-transparent z-[1]" />
      <div className="relative z-10 max-w-screen-xl mx-auto px-8 lg:px-16 w-full">
        <AnimatePresence mode="wait">
          <motion.div key={current} initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }} exit={{ opacity:0, y:-20 }} transition={{ duration:0.7 }} className="max-w-2xl">
            <motion.span initial={{ opacity:0, x:-20 }} animate={{ opacity:1, x:0 }} transition={{ delay:0.15 }}
              className="inline-block px-4 py-1.5 border border-gold/40 text-[10px] tracking-[0.4em] uppercase text-gold mb-8">{slide.tag}</motion.span>
            <h1 className="font-display text-[clamp(3rem,7vw,6rem)] font-light leading-[1.02] text-white mb-6">
              {slide.title.split('\n').map((line,i) => <span key={i} className="block">{line}</span>)}
            </h1>
            <p className="text-[15px] text-white/65 font-light leading-relaxed mb-10 max-w-[440px]">{slide.sub}</p>
            <div className="flex gap-4 flex-wrap">
              <button onClick={() => navigate(slide.link)} className="inline-flex items-center gap-3 bg-white text-charcoal px-8 py-4 text-[11px] tracking-[0.2em] uppercase font-medium hover:bg-gold hover:text-white transition-all duration-300">
                {slide.cta} <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </button>
              <button onClick={() => navigate('/lookbook')} className="inline-flex items-center gap-3 border border-white/40 text-white px-8 py-4 text-[11px] tracking-[0.2em] uppercase font-medium hover:bg-white/10 transition-all duration-300">
                View Lookbook
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2 z-10">
        {HERO_SLIDES.map((_,i) => (
          <button key={i} onClick={() => setCurrent(i)} className={`h-[2px] transition-all duration-500 ${i===current ? 'w-14 bg-gold' : 'w-6 bg-white/30'}`} />
        ))}
      </div>
    </section>
  )
}

// ─── Categories ──────────────────────────────────────────────
function Categories() {
  const navigate = useNavigate()
  const [ref, inView] = useInView({ triggerOnce:true, threshold:0.1 })
  return (
    <section ref={ref} className="py-24 bg-white">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
        <motion.div initial={{ opacity:0, y:20 }} animate={inView?{ opacity:1, y:0 }:{}} className="flex items-end justify-between mb-10">
          <div><p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-2">Shop by Category</p><h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-light">Every Style,<br />Every Season</h2></div>
          <Link to="/products" className="hidden md:inline-flex border border-charcoal px-6 py-3 text-[11px] tracking-widest uppercase hover:bg-charcoal hover:text-white transition-all">View All</Link>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {CATEGORIES.map((cat,i) => (
            <motion.div key={cat.id} initial={{ opacity:0, y:20 }} animate={inView?{ opacity:1, y:0 }:{}} transition={{ delay:i*0.07 }}
              className={`relative overflow-hidden cursor-pointer group ${i===0 ? 'col-span-2 row-span-2' : ''}`}
              onClick={() => navigate(`/products?category=${cat.id}`)}>
              <img src={cat.image} alt={cat.label} className={`w-full object-cover transition-transform duration-700 group-hover:scale-105 ${i===0 ? 'h-[380px]' : 'h-[180px]'}`} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="font-display text-white text-xl font-light">{cat.label}</p>
                <p className="text-[11px] text-white/60 tracking-widest uppercase mt-0.5">{cat.count} styles</p>
              </div>
              <div className="absolute top-3 right-3 w-8 h-8 bg-white/15 backdrop-blur-sm rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Featured Products ────────────────────────────────────────
function FeaturedProducts() {
  const [active, setActive] = useState('all')
  const [ref, inView] = useInView({ triggerOnce:true, threshold:0.05 })
  const TABS = ['all','women','men','streetwear','accessories']
  const displayed = active==='all' ? PRODUCTS.slice(0,8) : PRODUCTS.filter(p => p.category===active)
  return (
    <section ref={ref} className="py-24 bg-cream" id="featured">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
        <motion.div initial={{ opacity:0, y:20 }} animate={inView?{ opacity:1, y:0 }:{}} className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-6">
          <div><p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-2">New Arrivals</p><h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-light">This Season's<br />Essentials</h2></div>
          <div className="flex gap-2 flex-wrap">
            {TABS.map(tab => (
              <button key={tab} onClick={() => setActive(tab)}
                className={`px-4 py-2 text-[11px] tracking-[0.15em] uppercase border transition-all duration-200 ${active===tab ? 'bg-charcoal text-white border-charcoal' : 'border-beige text-warm-gray hover:border-charcoal hover:text-charcoal'}`}>
                {tab}
              </button>
            ))}
          </div>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-10">
          {displayed.map((p,i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>
        <div className="text-center mt-14">
          <Link to="/products" className="inline-flex items-center gap-3 border border-charcoal px-10 py-4 text-[11px] tracking-widest uppercase hover:bg-charcoal hover:text-white transition-all duration-300">
            View All Products →
          </Link>
        </div>
      </div>
    </section>
  )
}

// ─── Flash Sale ───────────────────────────────────────────────
function FlashSale() {
  const { hours, minutes, seconds } = useCountdown(8*3600 + 34*60)
  const navigate = useNavigate()
  return (
    <div className="relative py-24 overflow-hidden" style={{ background:'linear-gradient(135deg,#1A1612,#2D2418)' }}>
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none">
        <span className="font-display text-[20vw] text-white/3 leading-none">SALE</span>
      </div>
      <div className="relative z-10 text-center">
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Flash Sale — Limited Time</p>
        <h2 className="font-display text-[clamp(2.5rem,6vw,5rem)] font-light text-white mb-6">Up to <em className="italic text-gold">60% Off</em><br />Select Styles</h2>
        <div className="flex items-start justify-center gap-4 mb-8">
          {[{n:hours,l:'Hours'},{n:minutes,l:'Minutes'},{n:seconds,l:'Seconds'}].map((t,i) => (
            <div key={t.l} className="flex items-start gap-4">
              <div className="text-center"><div className="font-display text-5xl font-light text-gold leading-none min-w-[60px]">{t.n}</div><div className="text-[9px] tracking-[0.3em] uppercase text-white/40 mt-1">{t.l}</div></div>
              {i < 2 && <span className="font-display text-4xl text-gold/50 -mt-1">:</span>}
            </div>
          ))}
        </div>
        <button onClick={() => navigate('/products?sale=true')} className="inline-flex items-center gap-3 bg-gold text-white px-10 py-4 text-[11px] tracking-widest uppercase font-medium hover:bg-accent transition-colors duration-300">Shop the Sale →</button>
      </div>
    </div>
  )
}

// ─── Brand Story ──────────────────────────────────────────────
function BrandStory() {
  const [ref, inView] = useInView({ triggerOnce:true, threshold:0.1 })
  return (
    <section ref={ref} className="py-24 bg-cream">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          <motion.div initial={{ opacity:0, x:-30 }} animate={inView?{ opacity:1, x:0 }:{}} transition={{ duration:0.7 }} className="relative">
            <img src="https://images.unsplash.com/photo-1551163943-3f7fb696afbf?w=700&q=80" alt="VELORA Atelier" className="w-full aspect-[4/5] object-cover" />
            <div className="absolute -bottom-6 -right-6 w-36 h-36 bg-charcoal flex flex-col items-center justify-center text-center">
              <span className="font-display text-4xl font-light text-gold leading-none">12</span>
              <span className="text-[9px] tracking-[0.25em] uppercase text-white/60 mt-2">Years of<br />Excellence</span>
            </div>
          </motion.div>
          <motion.div initial={{ opacity:0, x:30 }} animate={inView?{ opacity:1, x:0 }:{}} transition={{ duration:0.7, delay:0.1 }}>
            <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Our Story</p>
            <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-light mb-6">Fashion as an<br />Art Form</h2>
            <p className="text-[15px] text-warm-gray leading-relaxed mb-5">VELORA was born from a belief that clothing is more than fabric — it's expression, identity, and art. We curate pieces that transcend trends and become chapters of your personal story.</p>
            <p className="text-[15px] text-warm-gray leading-relaxed mb-8">Every stitch is intentional. Every collection tells a story. Every customer is our muse.</p>
            <Link to="/about" className="inline-flex items-center gap-3 border border-charcoal px-8 py-3.5 text-[11px] tracking-widest uppercase hover:bg-charcoal hover:text-white transition-all duration-300">Our Journey →</Link>
            <div className="grid grid-cols-3 gap-4 mt-10">
              {[{n:'240K+',l:'Happy Clients'},{n:'85+',l:'Collections'},{n:'48h',l:'Express Delivery'}].map(s => (
                <div key={s.l} className="border-t border-beige pt-4"><p className="font-display text-2xl font-light">{s.n}</p><p className="text-xs text-warm-gray mt-1">{s.l}</p></div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

// ─── Lookbook ─────────────────────────────────────────────────
function Lookbook() {
  const navigate = useNavigate()
  const [ref, inView] = useInView({ triggerOnce:true, threshold:0.1 })
  return (
    <section ref={ref} className="py-24" style={{ background:'#0F0F0F' }}>
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
        <motion.div initial={{ opacity:0, y:20 }} animate={inView?{ opacity:1, y:0 }:{}} className="text-center mb-12">
          <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">2026 Lookbook</p>
          <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-light text-white">Style Stories</h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {LOOKBOOK_ITEMS.map((look,i) => (
            <motion.div key={look.title} initial={{ opacity:0, y:30 }} animate={inView?{ opacity:1, y:0 }:{}} transition={{ delay:i*0.1 }}
              className="relative overflow-hidden cursor-pointer group" onClick={() => navigate(look.link)}>
              <img src={look.image} alt={look.title} className="w-full aspect-[2/3] object-cover transition-transform duration-700 group-hover:scale-[1.03]" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-8">
                <p className="text-[10px] tracking-[0.3em] uppercase text-gold mb-2">{look.season}</p>
                <h3 className="font-display text-2xl font-light text-white mb-3">{look.title}</h3>
                <span className="text-[11px] tracking-widest uppercase text-white/50 group-hover:text-gold transition-colors duration-300 flex items-center gap-2">View Collection <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Testimonials ─────────────────────────────────────────────
function Testimonials() {
  const [ref, inView] = useInView({ triggerOnce:true, threshold:0.1 })
  return (
    <section ref={ref} className="py-24 bg-white">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
        <motion.div initial={{ opacity:0, y:20 }} animate={inView?{ opacity:1, y:0 }:{}} className="text-center mb-12">
          <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">What Clients Say</p>
          <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-light">Worn With <em className="italic">Love</em></h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t,i) => (
            <motion.div key={t.name} initial={{ opacity:0, y:24 }} animate={inView?{ opacity:1, y:0 }:{}} transition={{ delay:i*0.1 }} className="relative bg-cream p-8">
              <span className="absolute top-4 left-6 font-display text-7xl text-gold/25 leading-none select-none">"</span>
              <p className="font-display text-[1.05rem] italic font-light leading-relaxed text-charcoal mb-6 pt-6">{t.text}</p>
              <div className="flex items-center gap-3">
                <img src={t.avatar} alt={t.name} className="w-11 h-11 rounded-full object-cover flex-shrink-0" />
                <div><p className="text-sm font-medium">{t.name}</p><p className="text-xs text-warm-gray">{t.meta}</p><p className="text-gold text-xs mt-0.5">★★★★★</p></div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

// ─── Gallery ──────────────────────────────────────────────────
function Gallery() {
  return (
    <section className="pb-24 bg-white">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 text-center mb-10">
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">@velora.official</p>
        <h2 className="font-display text-[clamp(2rem,4vw,3.2rem)] font-light">Follow Our Story</h2>
      </div>
      <div className="grid grid-cols-3 md:grid-cols-6 gap-1">
        {GALLERY_IMAGES.map((src,i) => (
          <div key={i} className={`relative overflow-hidden cursor-pointer group ${i===0 ? 'col-span-2 row-span-2' : ''}`} style={{ minHeight: i===0 ? '300px' : '150px' }}>
            <img src={src} alt={`Gallery ${i+1}`} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
            <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-300 flex items-center justify-center">
              <svg className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

// ─── Newsletter ───────────────────────────────────────────────
function Newsletter() {
  const [email, setEmail] = useState('')
  const handle = () => { if (!isValidEmail(email)) { toast.error('Please enter a valid email'); return } toast.success('Welcome to the VELORA family! 💌'); setEmail('') }
  return (
    <section className="py-24 bg-charcoal">
      <div className="max-w-xl mx-auto px-6 text-center">
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Stay in the Loop</p>
        <h2 className="font-display text-[clamp(2rem,5vw,3rem)] font-light text-white mb-4">Style Delivered<br />to Your Inbox</h2>
        <p className="text-sm text-white/50 leading-relaxed mb-8">First access to collections, exclusive deals, and private sale events. Join 120,000+ fashion lovers.</p>
        <div className="flex max-w-[420px] mx-auto">
          <input type="email" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key==='Enter' && handle()} placeholder="Your email address"
            className="flex-1 bg-white/8 border border-white/15 px-5 py-3.5 text-sm text-white placeholder:text-white/35 outline-none focus:border-gold transition-colors" />
          <button onClick={handle} className="bg-gold text-white px-6 text-[11px] tracking-widest uppercase font-medium hover:bg-accent transition-colors border border-gold">Subscribe</button>
        </div>
      </div>
    </section>
  )
}

// ─── AI Strip ─────────────────────────────────────────────────
function AIStrip() {
  const navigate = useNavigate()
  return (
    <section className="py-20 bg-cream border-y border-beige">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-8">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 bg-charcoal rounded-full flex items-center justify-center text-2xl flex-shrink-0">🤖</div>
            <div>
              <p className="text-[10px] tracking-[0.3em] uppercase text-gold mb-1">AI-Powered Styling</p>
              <h3 className="font-display text-2xl font-light">Let AI Build Your Perfect Outfit</h3>
              <p className="text-sm text-warm-gray mt-1">Tell us your vibe, we'll curate the look — in seconds.</p>
            </div>
          </div>
          <button onClick={() => navigate('/ai-stylist')} className="flex-shrink-0 bg-charcoal text-white px-8 py-4 text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">
            Try AI Stylist →
          </button>
        </div>
      </div>
    </section>
  )
}

export default function Home() {
  return (
    <div>
      <Hero />
      <Ticker />
      <Categories />
      <FeaturedProducts />
      <FlashSale />
      <BrandStory />
      <Lookbook />
      <Testimonials />
      <Gallery />
      <AIStrip />
      <Newsletter />
    </div>
  )
}
