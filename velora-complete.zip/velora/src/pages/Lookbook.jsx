import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { LOOKBOOK_ITEMS, PRODUCTS } from '../data/products'
import ProductCard from '../components/product/ProductCard'

const LOOKS = [
  { id:1, season:'Summer 2026', title:'Desert Noir', desc:'Sun-bleached palettes and fluid silhouettes. Fashion for the wanderer with impeccable taste.',
    image:'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=1200&q=85',
    products:['w-001','w-003','a-002'] },
  { id:2, season:'Resort 2026', title:'Midnight Blue', desc:'Deep, saturated tones meet luxurious fabrications. For evenings that demand presence.',
    image:'https://images.unsplash.com/photo-1594938298603-c8148c4b4471?w=1200&q=85',
    products:['w-002','a-001','sn-001'] },
  { id:3, season:'Capsule 2026', title:'Velvet Dusk', desc:'A study in restraint. Monochromatic, textured, impossibly chic.',
    image:'https://images.unsplash.com/photo-1566174053879-31528523f8ae?w=1200&q=85',
    products:['w-004','m-001','h-001'] },
  { id:4, season:'Street Edit', title:'Urban Grunge', desc:'Streetwear elevated. Bold pieces for the city that never sleeps.',
    image:'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1200&q=85',
    products:['s-001','m-002','sn-002'] },
]

export default function Lookbook() {
  const [active, setActive] = useState(LOOKS[0])
  const [ref, inView] = useInView({ triggerOnce:true, threshold:0.1 })

  const lookProducts = PRODUCTS.filter(p => active.products.includes(p.id))

  return (
    <div className="min-h-screen bg-deep pt-[72px]">
      {/* Hero */}
      <div className="relative h-[60vh] overflow-hidden">
        <motion.img key={active.id} initial={{ opacity:0, scale:1.05 }} animate={{ opacity:1, scale:1 }} transition={{ duration:0.8 }}
          src={active.image} alt={active.title} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-deep via-black/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-12 max-w-screen-xl mx-auto">
          <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-2">{active.season}</p>
          <h1 className="font-display text-5xl lg:text-7xl font-light text-white mb-3">{active.title}</h1>
          <p className="text-white/60 max-w-md text-[15px]">{active.desc}</p>
        </div>
      </div>

      {/* Look selector */}
      <div className="bg-charcoal border-b border-white/10">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
          <div className="flex gap-8 overflow-x-auto">
            {LOOKS.map(look => (
              <button key={look.id} onClick={() => setActive(look)}
                className={`py-5 text-[11px] tracking-widest uppercase whitespace-nowrap border-b-2 transition-all ${active.id===look.id ? 'border-gold text-gold' : 'border-transparent text-white/40 hover:text-white/70'}`}>
                {look.title}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Shop the look */}
      <div ref={ref} className="max-w-screen-xl mx-auto px-6 lg:px-10 py-16">
        <motion.div initial={{ opacity:0, y:20 }} animate={inView?{ opacity:1, y:0 }:{}} className="mb-10">
          <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-2">Shop the Look</p>
          <h2 className="font-display text-3xl font-light text-white">{active.title}</h2>
        </motion.div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-x-5 gap-y-10">
          {lookProducts.map((p, i) => <ProductCard key={p.id} product={p} index={i} />)}
        </div>

        {/* Gallery grid */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-3">
          {LOOKS.map(look => (
            <motion.div key={look.id} whileHover={{ scale:1.02 }} onClick={() => setActive(look)}
              className={`relative overflow-hidden cursor-pointer aspect-[3/4] ${active.id===look.id ? 'ring-2 ring-gold' : ''}`}>
              <img src={look.image} alt={look.title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-4">
                <p className="text-[10px] uppercase tracking-widest text-gold">{look.season}</p>
                <p className="font-display text-lg text-white font-light">{look.title}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}
