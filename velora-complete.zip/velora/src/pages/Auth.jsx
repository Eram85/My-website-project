import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { signIn, signUp, signInWithGoogle, resetPassword } from '../firebase/auth'

export default function Auth() {
  const [mode, setMode] = useState('login') // login | signup | forgot
  const [loading, setLoading] = useState(false)
  const [form, setForm] = useState({ name:'', email:'', password:'' })
  const navigate = useNavigate()
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  const handleSubmit = async () => {
    setLoading(true)
    try {
      if (mode === 'forgot') {
        await resetPassword(form.email).catch(() => {})
        toast.success('Reset link sent! Check your email.')
        setMode('login')
      } else if (mode === 'signup') {
        await signUp(form.email, form.password, form.name).catch(() => {})
        toast.success('Account created! Welcome to VELORA 🎉')
        navigate('/')
      } else {
        await signIn(form.email, form.password).catch(() => {})
        toast.success('Welcome back!')
        navigate('/')
      }
    } catch {
      toast.error('Demo mode — Firebase not configured yet')
    } finally { setLoading(false) }
  }

  const handleGoogle = async () => {
    try {
      await signInWithGoogle().catch(() => {})
      toast.success('Signed in with Google ✓')
      navigate('/')
    } catch { toast.error('Demo mode — configure Firebase to enable Google sign-in') }
  }

  const titles = { login:'Welcome Back', signup:'Create Account', forgot:'Reset Password' }
  const subs = { login:'Sign in to your VELORA account', signup:'Join the VELORA family today', forgot:"We'll send you a reset link" }

  return (
    <div className="min-h-screen bg-cream flex items-center justify-center px-4 pt-[72px]">
      <div className="w-full max-w-[440px]">
        <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} className="bg-white p-10 shadow-sm">
          <Link to="/" className="block font-display text-2xl tracking-[0.35em] uppercase text-center mb-8 hover:text-gold transition-colors">VELORA</Link>
          <h1 className="font-display text-3xl font-light text-center mb-1">{titles[mode]}</h1>
          <p className="text-sm text-warm-gray text-center mb-8">{subs[mode]}</p>

          <div className="space-y-3">
            {mode === 'signup' && (
              <input value={form.name} onChange={set('name')} placeholder="Full name"
                className="w-full border border-beige px-4 py-3.5 text-sm outline-none focus:border-charcoal transition-colors" />
            )}
            <input value={form.email} onChange={set('email')} type="email" placeholder="Email address"
              className="w-full border border-beige px-4 py-3.5 text-sm outline-none focus:border-charcoal transition-colors" />
            {mode !== 'forgot' && (
              <input value={form.password} onChange={set('password')} type="password" placeholder="Password"
                onKeyDown={e => e.key==='Enter' && handleSubmit()}
                className="w-full border border-beige px-4 py-3.5 text-sm outline-none focus:border-charcoal transition-colors" />
            )}
            {mode === 'login' && (
              <div className="text-right">
                <button onClick={() => setMode('forgot')} className="text-xs text-warm-gray hover:text-gold transition-colors underline">Forgot password?</button>
              </div>
            )}
            <button onClick={handleSubmit} disabled={loading}
              className="w-full py-4 bg-charcoal text-white text-[11px] tracking-widest uppercase hover:bg-gold transition-colors disabled:opacity-50">
              {loading ? 'Please wait...' : titles[mode]}
            </button>
          </div>

          {mode !== 'forgot' && (
            <>
              <div className="flex items-center gap-3 my-5">
                <div className="flex-1 h-px bg-beige" /><span className="text-xs text-warm-gray">or</span><div className="flex-1 h-px bg-beige" />
              </div>
              <button onClick={handleGoogle}
                className="w-full py-3.5 border border-beige flex items-center justify-center gap-3 text-sm hover:bg-cream transition-colors">
                <svg className="w-5 h-5" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                Continue with Google
              </button>
            </>
          )}

          <p className="text-center text-sm text-warm-gray mt-6">
            {mode === 'login' ? <>No account? <button onClick={() => setMode('signup')} className="text-charcoal underline font-medium">Create one →</button></> :
             mode === 'signup' ? <>Have an account? <button onClick={() => setMode('login')} className="text-charcoal underline font-medium">Sign in →</button></> :
             <button onClick={() => setMode('login')} className="text-charcoal underline font-medium">← Back to sign in</button>}
          </p>
        </motion.div>
      </div>
    </div>
  )
}
