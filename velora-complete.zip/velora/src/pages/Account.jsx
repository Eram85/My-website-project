import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { useAuth } from '../context/AuthContext'
import { useWishlistStore } from '../context/useStore'
import { logOut } from '../firebase/auth'
import { formatPrice, formatDate } from '../utils'

const MOCK_ORDERS = [
  { id:'VLR-A1B2C3', date:'2026-04-10', status:'delivered', total:614, items:3 },
  { id:'VLR-D4E5F6', date:'2026-03-22', status:'shipped',   total:265, items:1 },
  { id:'VLR-G7H8I9', date:'2026-02-15', status:'delivered', total:189, items:1 },
]
const STATUS = { delivered:{bg:'#D1FAE5',text:'#065F46',label:'Delivered'}, shipped:{bg:'#DBEAFE',text:'#1E40AF',label:'Shipped'}, processing:{bg:'#FEF3C7',text:'#92400E',label:'Processing'}, pending:{bg:'#FEE2E2',text:'#991B1B',label:'Pending'} }

export default function Account() {
  const [tab, setTab] = useState('orders')
  const { user } = useAuth()
  const { items: wishlist } = useWishlistStore()
  const navigate = useNavigate()

  const handleLogout = async () => {
    await logOut().catch(() => {})
    toast.success('Signed out successfully')
    navigate('/')
  }

  const TABS = [
    { id:'orders',    label:'Orders' },
    { id:'wishlist',  label:'Wishlist' },
    { id:'addresses', label:'Addresses' },
    { id:'settings',  label:'Settings' },
  ]

  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-12">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-1">My Account</p>
            <h1 className="font-display text-3xl font-light">
              {user ? `Hello, ${user.displayName?.split(' ')[0] || 'Friend'}` : 'My Account'}
            </h1>
          </div>
          <button onClick={handleLogout} className="border border-beige px-6 py-2.5 text-xs uppercase tracking-widest hover:bg-charcoal hover:text-white transition-all">
            Sign Out
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[220px_1fr] gap-8">
          {/* Sidebar */}
          <div className="space-y-1">
            {TABS.map(t => (
              <button key={t.id} onClick={() => setTab(t.id)}
                className={`w-full text-left px-4 py-3 text-sm transition-all ${tab===t.id ? 'bg-charcoal text-white' : 'hover:bg-beige text-charcoal'}`}>
                {t.label}
              </button>
            ))}
          </div>

          {/* Content */}
          <div>
            {tab === 'orders' && (
              <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
                <h2 className="font-display text-xl font-light mb-6">Order History</h2>
                {MOCK_ORDERS.length === 0 ? (
                  <div className="text-center py-20 text-warm-gray">
                    <p className="font-display text-2xl mb-3">No orders yet</p>
                    <Link to="/products" className="border border-charcoal px-8 py-3 text-xs uppercase tracking-widest hover:bg-charcoal hover:text-white transition-all inline-block">Shop Now</Link>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {MOCK_ORDERS.map(order => {
                      const s = STATUS[order.status]
                      return (
                        <div key={order.id} className="bg-white border border-beige p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <p className="font-mono text-sm font-medium">{order.id}</p>
                              <p className="text-xs text-warm-gray mt-1">{new Date(order.date).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</p>
                            </div>
                            <span className="text-xs font-medium px-3 py-1.5" style={{ background:s.bg, color:s.text }}>{s.label}</span>
                          </div>
                          <div className="flex items-center justify-between text-sm border-t border-beige pt-4">
                            <span className="text-warm-gray">{order.items} item{order.items>1?'s':''}</span>
                            <span className="font-medium">{formatPrice(order.total)}</span>
                          </div>
                          {/* Progress bar */}
                          <div className="flex gap-1 mt-4">
                            {['placed','processing','shipped','delivered'].map((st,i) => {
                              const idx = ['placed','processing','shipped','delivered'].indexOf(order.status)
                              return <div key={st} className={`flex-1 h-1 rounded-full transition-colors ${i <= (idx === -1 ? 0 : idx) ? 'bg-gold' : 'bg-beige'}`} />
                            })}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </motion.div>
            )}

            {tab === 'wishlist' && (
              <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
                <h2 className="font-display text-xl font-light mb-6">My Wishlist ({wishlist.length})</h2>
                {wishlist.length === 0 ? (
                  <div className="text-center py-20 text-warm-gray">
                    <p className="font-display text-2xl mb-3">Your wishlist is empty</p>
                    <Link to="/products" className="border border-charcoal px-8 py-3 text-xs uppercase tracking-widest hover:bg-charcoal hover:text-white transition-all inline-block">Explore Collection</Link>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
                    {wishlist.map(p => (
                      <Link key={p.id} to={`/product/${p.id}`} className="bg-white border border-beige group">
                        <div className="aspect-[3/4] overflow-hidden">
                          <img src={p.images?.[0]} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        </div>
                        <div className="p-3">
                          <p className="text-xs text-warm-gray">{p.brand}</p>
                          <p className="font-display text-sm">{p.name}</p>
                          <p className="text-sm font-medium mt-1">{formatPrice(p.price)}</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                )}
              </motion.div>
            )}

            {tab === 'addresses' && (
              <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
                <h2 className="font-display text-xl font-light mb-6">Saved Addresses</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="border border-beige p-5 bg-white">
                    <div className="flex justify-between mb-3">
                      <span className="text-[10px] tracking-widest uppercase text-gold font-medium">Default</span>
                      <button className="text-xs text-warm-gray hover:text-charcoal underline">Edit</button>
                    </div>
                    <p className="text-sm leading-relaxed text-warm-gray">{user?.displayName || 'John Doe'}<br />123 Fashion Avenue<br />Dhaka 1000, Bangladesh</p>
                  </div>
                  <button className="border-2 border-dashed border-beige p-5 flex flex-col items-center justify-center gap-2 hover:border-charcoal transition-colors text-warm-gray hover:text-charcoal">
                    <span className="text-2xl">+</span>
                    <span className="text-xs uppercase tracking-widest">Add Address</span>
                  </button>
                </div>
              </motion.div>
            )}

            {tab === 'settings' && (
              <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }}>
                <h2 className="font-display text-xl font-light mb-6">Account Settings</h2>
                <div className="bg-white border border-beige p-6 space-y-4 max-w-lg">
                  {[
                    { label:'Full Name',      value:user?.displayName || '', placeholder:'Your full name' },
                    { label:'Email Address',  value:user?.email || '',       placeholder:'your@email.com' },
                    { label:'Phone Number',   value:'',                      placeholder:'+880 1XXXXXXXXX' },
                  ].map(f => (
                    <div key={f.label}>
                      <label className="block text-[10px] tracking-widest uppercase text-warm-gray mb-1.5">{f.label}</label>
                      <input defaultValue={f.value} placeholder={f.placeholder}
                        className="w-full border border-beige px-4 py-3 text-sm outline-none focus:border-charcoal transition-colors" />
                    </div>
                  ))}
                  <button onClick={() => toast.success('Profile updated!')}
                    className="w-full py-3.5 bg-charcoal text-white text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">
                    Save Changes
                  </button>
                </div>
                <div className="mt-6 bg-white border border-red-100 p-6 max-w-lg">
                  <h3 className="font-medium text-red-600 mb-2">Danger Zone</h3>
                  <p className="text-xs text-warm-gray mb-4">Once you delete your account, there is no going back.</p>
                  <button className="border border-red-200 text-red-500 px-6 py-2.5 text-xs uppercase tracking-widest hover:bg-red-50 transition-colors">Delete Account</button>
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
