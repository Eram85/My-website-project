import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Link } from 'react-router-dom'

const TEAM = [
  { name:'Isabelle Moreau', role:'Creative Director', img:'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&q=80' },
  { name:'Marcus Chen', role:'Head of Design', img:'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&q=80' },
  { name:'Aisha Okonkwo', role:'Brand Director', img:'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?w=400&q=80' },
  { name:'Lucas Ferreira', role:'Head of Styling', img:'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&q=80' },
]

const VALUES = [
  { icon:'✦', title:'Craftsmanship', desc:'Every piece is designed with meticulous attention to detail, sourcing only the finest materials from around the world.' },
  { icon:'◈', title:'Sustainability', desc:'We are committed to responsible fashion. 60% of our collection uses sustainable or recycled materials.' },
  { icon:'❋', title:'Inclusivity', desc:'Fashion is for everyone. Our collections are designed to celebrate all body types, cultures, and identities.' },
  { icon:'◇', title:'Innovation', desc:'We blend timeless elegance with cutting-edge design technology to create pieces that define tomorrow.' },
]

export default function About() {
  const [r1, i1] = useInView({ triggerOnce:true, threshold:0.1 })
  const [r2, i2] = useInView({ triggerOnce:true, threshold:0.1 })
  const [r3, i3] = useInView({ triggerOnce:true, threshold:0.1 })

  return (
    <div className="min-h-screen pt-[72px]">
      {/* Hero */}
      <div className="relative h-[70vh] overflow-hidden">
        <img src="https://images.unsplash.com/photo-1469334031218-e382a71b716b?w=1600&q=85" alt="About VELORA" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/20" />
        <div className="absolute inset-0 flex items-center">
          <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
            <motion.div initial={{ opacity:0, y:30 }} animate={{ opacity:1, y:0 }} transition={{ duration:0.8 }}>
              <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-4">Est. 2014 · Paris</p>
              <h1 className="font-display text-5xl lg:text-7xl font-light text-white mb-6 leading-tight">Fashion as an<br /><em className="italic">Art Form</em></h1>
              <p className="text-white/60 max-w-lg text-[15px] leading-relaxed">
                VELORA was born from a belief that clothing is more than fabric — it's expression, identity, and art.
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Story */}
      <section className="py-24 bg-cream">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
          <div ref={r1} className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div initial={{ opacity:0, x:-30 }} animate={i1?{ opacity:1, x:0 }:{}} transition={{ duration:0.7 }}>
              <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Our Story</p>
              <h2 className="font-display text-4xl font-light mb-6">Built on a Belief</h2>
              <p className="text-warm-gray text-[15px] leading-relaxed mb-4">
                Founded in 2014 by Isabelle Moreau in Paris, VELORA started as a small atelier with a radical idea: that luxury fashion should be accessible without sacrificing artistry or ethics.
              </p>
              <p className="text-warm-gray text-[15px] leading-relaxed mb-4">
                Twelve years and 85 collections later, we serve 240,000+ customers across 48 countries. Every piece still carries the soul of that first atelier — handcrafted, intentional, beautiful.
              </p>
              <p className="text-warm-gray text-[15px] leading-relaxed mb-8">
                We don't follow trends. We set the tone for what fashion feels like when it's done right.
              </p>
              <div className="grid grid-cols-3 gap-4">
                {[{n:'2014',l:'Founded'},{n:'48',l:'Countries'},{n:'240K+',l:'Clients'}].map(s => (
                  <div key={s.l} className="border-t border-beige pt-4">
                    <p className="font-display text-2xl font-light">{s.n}</p>
                    <p className="text-xs text-warm-gray mt-1">{s.l}</p>
                  </div>
                ))}
              </div>
            </motion.div>
            <motion.div initial={{ opacity:0, x:30 }} animate={i1?{ opacity:1, x:0 }:{}} transition={{ duration:0.7, delay:0.1 }} className="relative">
              <img src="https://images.unsplash.com/photo-1551163943-3f7fb696afbf?w=700&q=80" alt="VELORA Atelier" className="w-full aspect-[4/5] object-cover" />
              <div className="absolute -bottom-6 -left-6 w-36 h-36 bg-gold flex items-center justify-center text-center">
                <div><p className="font-display text-4xl font-light text-white">12</p><p className="text-[9px] tracking-widest uppercase text-white/70 mt-1">Years of<br />Excellence</p></div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section ref={r2} className="py-24 bg-white">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
          <motion.div initial={{ opacity:0, y:20 }} animate={i2?{ opacity:1, y:0 }:{}} className="text-center mb-12">
            <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">What We Stand For</p>
            <h2 className="font-display text-4xl font-light">Our Values</h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {VALUES.map((v, i) => (
              <motion.div key={v.title} initial={{ opacity:0, y:24 }} animate={i2?{ opacity:1, y:0 }:{}} transition={{ delay:i*0.1 }} className="text-center p-6">
                <div className="text-4xl text-gold mb-4">{v.icon}</div>
                <h3 className="font-display text-xl font-light mb-3">{v.title}</h3>
                <p className="text-sm text-warm-gray leading-relaxed">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section ref={r3} className="py-24 bg-cream">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10">
          <motion.div initial={{ opacity:0, y:20 }} animate={i3?{ opacity:1, y:0 }:{}} className="text-center mb-12">
            <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">The People Behind VELORA</p>
            <h2 className="font-display text-4xl font-light">Meet the Team</h2>
          </motion.div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {TEAM.map((t, i) => (
              <motion.div key={t.name} initial={{ opacity:0, y:24 }} animate={i3?{ opacity:1, y:0 }:{}} transition={{ delay:i*0.1 }} className="text-center group">
                <div className="aspect-square overflow-hidden mb-4">
                  <img src={t.img} alt={t.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <p className="font-display text-lg font-light">{t.name}</p>
                <p className="text-xs text-warm-gray uppercase tracking-widest mt-1">{t.role}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-charcoal text-center">
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Join the Journey</p>
        <h2 className="font-display text-4xl font-light text-white mb-8">Wear Your Story</h2>
        <Link to="/products" className="inline-flex items-center gap-3 bg-gold text-white px-10 py-4 text-[11px] tracking-widest uppercase hover:bg-accent transition-colors">
          Explore Collection →
        </Link>
      </section>
    </div>
  )
}
