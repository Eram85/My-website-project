import { useState } from 'react'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { isValidEmail } from '../utils'

export default function Contact() {
  const [form, setForm] = useState({ name:'', email:'', subject:'', message:'' })
  const [loading, setLoading] = useState(false)
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  const submit = async () => {
    if (!form.name || !form.email || !form.message) { toast.error('Please fill all required fields'); return }
    if (!isValidEmail(form.email)) { toast.error('Invalid email'); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 1000))
    toast.success("Message sent! We'll reply within 24 hours 📨")
    setForm({ name:'', email:'', subject:'', message:'' })
    setLoading(false)
  }

  const INFO = [
    { icon:'📍', label:'Headquarters', val:'12 Rue du Faubourg, Paris 75008' },
    { icon:'✉️', label:'Email', val:'hello@velora.com' },
    { icon:'📞', label:'Phone', val:'+33 1 23 45 67 89' },
    { icon:'⏰', label:'Hours', val:'Mon–Fri, 9am–6pm CET' },
  ]

  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      {/* Header */}
      <div className="bg-charcoal py-20 text-center">
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Get in Touch</p>
        <h1 className="font-display text-5xl font-light text-white">Contact Us</h1>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-16">
          {/* Form */}
          <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} className="bg-white p-8 border border-beige">
            <h2 className="font-display text-2xl font-light mb-6">Send a Message</h2>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {[{l:'Your Name *',k:'name',t:'text'},{l:'Email Address *',k:'email',t:'email'}].map(f => (
                  <div key={f.k}>
                    <label className="block text-[10px] tracking-widest uppercase text-warm-gray mb-1.5">{f.l}</label>
                    <input type={f.t} value={form[f.k]} onChange={set(f.k)} className="w-full border border-beige px-4 py-3 text-sm outline-none focus:border-charcoal transition-colors" />
                  </div>
                ))}
              </div>
              <div>
                <label className="block text-[10px] tracking-widest uppercase text-warm-gray mb-1.5">Subject</label>
                <select value={form.subject} onChange={set('subject')} className="w-full border border-beige px-4 py-3 text-sm outline-none focus:border-charcoal bg-white">
                  {['General Enquiry','Order Support','Returns & Refunds','Press & Media','Wholesale','Careers','Other'].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[10px] tracking-widest uppercase text-warm-gray mb-1.5">Message *</label>
                <textarea value={form.message} onChange={set('message')} rows={5} placeholder="Tell us how we can help..." className="w-full border border-beige px-4 py-3 text-sm outline-none focus:border-charcoal transition-colors resize-none" />
              </div>
              <button onClick={submit} disabled={loading} className="w-full py-4 bg-charcoal text-white text-[11px] tracking-widest uppercase hover:bg-gold transition-colors disabled:opacity-50">
                {loading ? 'Sending...' : 'Send Message →'}
              </button>
            </div>
          </motion.div>

          {/* Info */}
          <div className="space-y-6">
            <div className="bg-white border border-beige p-6">
              <h3 className="font-display text-xl font-light mb-5">Contact Information</h3>
              {INFO.map(i => (
                <div key={i.label} className="flex items-start gap-4 py-3 border-b border-beige last:border-0">
                  <span className="text-xl">{i.icon}</span>
                  <div><p className="text-[10px] tracking-widest uppercase text-warm-gray">{i.label}</p><p className="text-sm mt-0.5">{i.val}</p></div>
                </div>
              ))}
            </div>
            <div className="bg-gold p-6 text-white">
              <h3 className="font-display text-xl font-light mb-2">Fast Response Promise</h3>
              <p className="text-sm text-white/80 leading-relaxed">We reply to all enquiries within 24 hours during business days. For urgent order issues, use live chat for instant support.</p>
            </div>
            <div className="bg-white border border-beige p-6">
              <h3 className="font-display text-lg font-light mb-4">Follow VELORA</h3>
              <div className="flex gap-3">
                {['Instagram','Pinterest','TikTok','X/Twitter'].map(s => (
                  <button key={s} title={s} className="w-10 h-10 border border-beige flex items-center justify-center text-xs text-warm-gray hover:bg-charcoal hover:text-white hover:border-charcoal transition-all">
                    {s[0]}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
