import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const FAQS = [
  { q:'What are your shipping options and delivery times?', a:'We offer standard shipping (5–7 business days), express shipping (2–3 business days), and next-day delivery for orders placed before 12pm. Free standard shipping on all orders over $200.' },
  { q:'How do I return or exchange an item?', a:'We accept returns within 30 days of delivery. Items must be unworn, unwashed, and in original packaging with tags attached. Start your return through your account dashboard or contact our support team.' },
  { q:'How do I find my correct size?', a:'Visit our Size Guide page for detailed measurements. We recommend measuring yourself and comparing to our size chart. If between sizes, we generally recommend sizing up for a relaxed fit.' },
  { q:'Are your products ethically made?', a:'Yes. We are committed to ethical production. All our manufacturing partners are certified for fair wages and safe working conditions. 60% of our materials are sustainably sourced.' },
  { q:'Can I modify or cancel my order after placing it?', a:'Orders can be modified or cancelled within 1 hour of placement. After this window, the order enters processing and cannot be changed. Contact us immediately if you need to make changes.' },
  { q:'Do you ship internationally?', a:'Yes! We ship to 48+ countries worldwide. International shipping typically takes 7–14 business days. Import duties and taxes may apply depending on your country.' },
  { q:'How do I care for my VELORA pieces?', a:'Care instructions vary by garment and are printed on the label. Silk pieces require dry cleaning or gentle hand washing. Our cotton and linen pieces are generally machine washable on a delicate cycle.' },
  { q:'Do you offer gift wrapping?', a:'Yes! Select gift wrapping at checkout for $8. Your order will arrive in our signature black box with gold ribbon, tissue paper, and a handwritten note if requested.' },
  { q:'Is my payment information secure?', a:'Absolutely. All payments are processed through Stripe, which uses 256-bit SSL encryption. We never store your card details on our servers.' },
  { q:'Do you have a loyalty program?', a:'Yes — VELORA Members earn 1 point per $1 spent. Points can be redeemed for discounts, early access to sales, and exclusive member events. Sign up for free.' },
]

export default function FAQ() {
  const [open, setOpen] = useState(null)
  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      <div className="bg-charcoal py-20 text-center">
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Support</p>
        <h1 className="font-display text-5xl font-light text-white">Frequently Asked Questions</h1>
      </div>
      <div className="max-w-3xl mx-auto px-6 py-16">
        <div className="space-y-2">
          {FAQS.map((faq, i) => (
            <div key={i} className="bg-white border border-beige overflow-hidden">
              <button onClick={() => setOpen(open===i ? null : i)} className="w-full flex items-center justify-between px-6 py-5 text-left hover:bg-cream transition-colors">
                <span className="font-display text-lg font-light pr-8">{faq.q}</span>
                <span className={`text-xl text-warm-gray flex-shrink-0 transition-transform duration-300 ${open===i ? 'rotate-45' : ''}`}>+</span>
              </button>
              <AnimatePresence>
                {open === i && (
                  <motion.div initial={{ height:0, opacity:0 }} animate={{ height:'auto', opacity:1 }} exit={{ height:0, opacity:0 }} transition={{ duration:0.3 }}>
                    <p className="px-6 pb-5 text-sm text-warm-gray leading-relaxed border-t border-beige pt-4">{faq.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center bg-white border border-beige p-8">
          <p className="font-display text-xl font-light mb-2">Still have questions?</p>
          <p className="text-sm text-warm-gray mb-5">Our team is available Mon–Fri, 9am–6pm CET</p>
          <a href="/contact" className="inline-flex items-center gap-2 bg-charcoal text-white px-8 py-3.5 text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">Contact Us →</a>
        </div>
      </div>
    </div>
  )
}
