import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import toast from 'react-hot-toast'
import { PRODUCTS } from '../data/products'
import { useCartStore, useUIStore } from '../context/useStore'
import { formatPrice } from '../utils'

const OCCASIONS = ['Work Meeting','Date Night','Weekend Casual','Beach Resort','Formal Event','Street Style','Travel','Workout']
const VIBES = ['Minimalist','Bold & Edgy','Classic Luxury','Streetwear','Romantic','Avant-garde','Business Chic','Boho']
const BUDGETS = ['Under $200','$200–$500','$500–$1000','No limit']

export default function AIStylist() {
  const [step, setStep] = useState(0)
  const [prefs, setPrefs] = useState({ occasion:'', vibe:'', budget:'', gender:'women' })
  const [loading, setLoading] = useState(false)
  const [outfit, setOutfit] = useState(null)
  const { addItem, openCart } = useCartStore()
  const { openProductModal } = useUIStore()

  const toggle = (key, val) => setPrefs(p => ({ ...p, [key]: p[key]===val ? '' : val }))

  const generate = async () => {
    setLoading(true)
    await new Promise(r => setTimeout(r, 2200))
    // Filter products based on preferences
    let pool = PRODUCTS
    if (prefs.gender !== 'all') pool = pool.filter(p => p.category === prefs.gender || ['sneakers','accessories','hoodies'].includes(p.category))
    if (prefs.budget === 'Under $200') pool = pool.filter(p => p.price < 200)
    if (prefs.budget === '$200–$500') pool = pool.filter(p => p.price >= 200 && p.price <= 500)
    // Pick 3 varied pieces
    const shuffled = pool.sort(() => 0.5 - Math.random())
    const tops = shuffled.filter(p => ['women','men'].includes(p.category)).slice(0, 1)
    const bottoms = shuffled.filter(p => p.category === 'streetwear').slice(0, 1)
    const acc = shuffled.filter(p => ['accessories','sneakers','hoodies'].includes(p.category)).slice(0, 1)
    setOutfit([...tops, ...bottoms, ...acc].slice(0, 3))
    setLoading(false)
    setStep(2)
  }

  const addAll = () => {
    outfit.forEach(p => addItem(p, p.sizes?.[0], p.colors?.[0]||''))
    openCart()
    toast.success('All outfit pieces added to your bag! 🛍')
  }

  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      {/* Hero */}
      <div className="bg-charcoal py-20 text-center">
        <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }}>
          <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Powered by AI</p>
          <h1 className="font-display text-5xl font-light text-white mb-4">Your Personal Style AI</h1>
          <p className="text-white/50 max-w-md mx-auto text-[15px] leading-relaxed">
            Tell us your vibe and occasion — we'll build the perfect VELORA outfit for you in seconds.
          </p>
        </motion.div>
      </div>

      <div className="max-w-3xl mx-auto px-6 py-16">
        {/* Step 0: Preferences */}
        {step === 0 && (
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} className="space-y-10">
            <div>
              <h2 className="font-display text-2xl font-light mb-1">What's the occasion?</h2>
              <p className="text-sm text-warm-gray mb-4">Select all that apply</p>
              <div className="flex flex-wrap gap-2">
                {OCCASIONS.map(o => (
                  <button key={o} onClick={() => toggle('occasion', o)}
                    className={`px-5 py-2.5 border text-sm transition-all ${prefs.occasion===o ? 'bg-charcoal text-white border-charcoal' : 'border-beige hover:border-charcoal'}`}>
                    {o}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h2 className="font-display text-2xl font-light mb-1">Your vibe?</h2>
              <p className="text-sm text-warm-gray mb-4">How do you want to feel?</p>
              <div className="flex flex-wrap gap-2">
                {VIBES.map(v => (
                  <button key={v} onClick={() => toggle('vibe', v)}
                    className={`px-5 py-2.5 border text-sm transition-all ${prefs.vibe===v ? 'bg-charcoal text-white border-charcoal' : 'border-beige hover:border-charcoal'}`}>
                    {v}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h2 className="font-display text-2xl font-light mb-4">Budget range?</h2>
              <div className="flex flex-wrap gap-2">
                {BUDGETS.map(b => (
                  <button key={b} onClick={() => toggle('budget', b)}
                    className={`px-5 py-2.5 border text-sm transition-all ${prefs.budget===b ? 'bg-charcoal text-white border-charcoal' : 'border-beige hover:border-charcoal'}`}>
                    {b}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h2 className="font-display text-2xl font-light mb-4">Shopping for?</h2>
              <div className="flex gap-2">
                {['women','men','all'].map(g => (
                  <button key={g} onClick={() => setPrefs(p => ({ ...p, gender:g }))}
                    className={`px-8 py-3 border text-sm uppercase tracking-widest transition-all ${prefs.gender===g ? 'bg-charcoal text-white border-charcoal' : 'border-beige hover:border-charcoal'}`}>
                    {g}
                  </button>
                ))}
              </div>
            </div>
            <button onClick={generate}
              className="w-full py-4 bg-gold text-white text-[11px] tracking-widest uppercase hover:bg-accent transition-colors">
              Generate My Outfit →
            </button>
          </motion.div>
        )}

        {/* Loading */}
        {loading && (
          <motion.div initial={{ opacity:0 }} animate={{ opacity:1 }} className="text-center py-24">
            <div className="w-16 h-16 border-2 border-beige border-t-gold rounded-full animate-spin mx-auto mb-6" />
            <p className="font-display text-xl font-light">Curating your perfect look...</p>
            <p className="text-sm text-warm-gray mt-2">Analyzing {PRODUCTS.length} pieces</p>
          </motion.div>
        )}

        {/* Results */}
        {step === 2 && outfit && (
          <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }}>
            <div className="text-center mb-10">
              <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-2">Your AI-Curated Look</p>
              <h2 className="font-display text-3xl font-light mb-2">{prefs.vibe || 'Your Perfect'} Outfit</h2>
              <p className="text-sm text-warm-gray">Curated for: {prefs.occasion || 'Every occasion'}</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
              {outfit.map((p, i) => (
                <motion.div key={p.id} initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ delay:i*0.15 }}
                  className="bg-white border border-beige overflow-hidden group cursor-pointer" onClick={() => openProductModal(p)}>
                  <div className="aspect-[3/4] overflow-hidden">
                    <img src={p.images?.[0]} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  </div>
                  <div className="p-4">
                    <p className="text-[10px] tracking-widest uppercase text-gold mb-0.5">{['Top','Bottom','Accent'][i] || 'Piece'}</p>
                    <p className="font-display text-base">{p.name}</p>
                    <p className="text-sm font-medium mt-1">{formatPrice(p.price)}</p>
                    <button onClick={e => { e.stopPropagation(); addItem(p, p.sizes?.[0], p.colors?.[0]||''); openCart(); toast.success('Added!') }}
                      className="w-full mt-3 py-2.5 bg-charcoal text-white text-[10px] tracking-widest uppercase hover:bg-gold transition-colors">
                      Add to Bag
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>

            <div className="bg-white border border-beige p-6 flex items-center justify-between gap-4 flex-wrap mb-6">
              <div>
                <p className="font-display text-xl font-light">Complete Outfit Total</p>
                <p className="text-sm text-warm-gray mt-1">{outfit.length} pieces · Free shipping</p>
              </div>
              <div className="text-right">
                <p className="font-display text-3xl">{formatPrice(outfit.reduce((s,p) => s+p.price, 0))}</p>
                <button onClick={addAll} className="mt-2 bg-gold text-white px-8 py-3 text-[11px] tracking-widest uppercase hover:bg-accent transition-colors">
                  Add All to Bag →
                </button>
              </div>
            </div>

            <button onClick={() => { setStep(0); setOutfit(null) }}
              className="w-full py-3.5 border border-beige text-[11px] tracking-widest uppercase hover:bg-beige transition-colors">
              ← Generate Another Look
            </button>
          </motion.div>
        )}
      </div>
    </div>
  )
}
