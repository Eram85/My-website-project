import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { useWishlistStore, useCartStore } from '../context/useStore'
import { formatPrice } from '../utils'

export default function Wishlist() {
  const { items, removeItem } = useWishlistStore()
  const { addItem, openCart } = useCartStore()
  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-12">
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-2">Saved Items</p>
        <h1 className="font-display text-3xl font-light mb-8">My Wishlist ({items.length})</h1>
        {items.length === 0 ? (
          <div className="text-center py-24">
            <div className="text-6xl opacity-20 mb-4">♡</div>
            <p className="font-display text-2xl text-warm-gray mb-6">Your wishlist is empty</p>
            <Link to="/products" className="inline-flex items-center gap-2 bg-charcoal text-white px-10 py-4 text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">
              Explore Collection →
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-5 gap-y-8">
            {items.map((p, i) => (
              <motion.div key={p.id} initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ delay:i*0.07 }} className="group bg-white">
                <Link to={`/product/${p.id}`} className="block relative overflow-hidden aspect-[3/4]">
                  <img src={p.images?.[0]} alt={p.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  {p.badge && <span className={`absolute top-3 left-3 px-2 py-0.5 text-[10px] tracking-widest uppercase ${p.badge==='sale'?'bg-red-600':'bg-charcoal'} text-white`}>{p.badge}</span>}
                </Link>
                <div className="p-3">
                  <p className="text-[10px] tracking-widest uppercase text-warm-gray mb-0.5">{p.brand}</p>
                  <Link to={`/product/${p.id}`} className="font-display text-sm hover:text-gold transition-colors">{p.name}</Link>
                  <p className="text-sm font-medium mt-1">{formatPrice(p.price)}</p>
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => { addItem(p, p.sizes?.[0], p.colors?.[0]||''); openCart(); toast.success('Added to bag!') }}
                      className="flex-1 py-2 bg-charcoal text-white text-[10px] tracking-widest uppercase hover:bg-gold transition-colors">
                      Add to Bag
                    </button>
                    <button onClick={() => { removeItem(p.id); toast.success('Removed') }}
                      className="w-9 h-9 border border-beige flex items-center justify-center text-warm-gray hover:text-red-500 hover:border-red-200 transition-colors text-sm">
                      ✕
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
