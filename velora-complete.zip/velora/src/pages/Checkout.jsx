import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { useCartStore } from '../context/useStore'
import { formatPrice, generateOrderId } from '../utils'

const steps = ['Shipping', 'Payment', 'Review']

export default function Checkout() {
  const { items, subtotal, total, discountAmount, isFreeShipping, clearCart } = useCartStore()
  const navigate = useNavigate()
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [shipping, setShipping] = useState({ firstName:'', lastName:'', email:'', phone:'', address:'', city:'', state:'', zip:'', country:'Bangladesh' })
  const [payment, setPayment] = useState({ card:'', name:'', expiry:'', cvv:'' })

  const setS = k => e => setShipping(f => ({ ...f, [k]: e.target.value }))
  const setP = k => e => setPayment(f => ({ ...f, [k]: e.target.value }))

  const shippingFee = isFreeShipping ? 0 : 15
  const grandTotal = total + shippingFee

  const placeOrder = async () => {
    setLoading(true)
    await new Promise(r => setTimeout(r, 1800))
    const orderId = generateOrderId()
    clearCart()
    navigate('/order-confirmation', { state: { orderId, total: grandTotal, email: shipping.email } })
  }

  const InputField = ({ label, value, onChange, type='text', placeholder='' }) => (
    <div>
      <label className="block text-[10px] tracking-widest uppercase text-warm-gray mb-1.5">{label}</label>
      <input type={type} value={value} onChange={onChange} placeholder={placeholder}
        className="w-full border border-beige px-4 py-3 text-sm outline-none focus:border-charcoal transition-colors bg-white" />
    </div>
  )

  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-12">
        <div className="mb-10">
          <Link to="/" className="font-display text-2xl tracking-[0.35em] uppercase block mb-6">VELORA</Link>
          <div className="flex items-center gap-4">
            {steps.map((s, i) => (
              <div key={s} className="flex items-center gap-2">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium transition-colors ${i <= step ? 'bg-charcoal text-white' : 'border border-beige text-warm-gray'}`}>
                  {i < step ? '✓' : i + 1}
                </div>
                <span className={`text-sm ${i === step ? 'text-charcoal font-medium' : 'text-warm-gray'}`}>{s}</span>
                {i < steps.length - 1 && <div className={`w-12 h-px ${i < step ? 'bg-charcoal' : 'bg-beige'}`} />}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-12">
          <div>
            {step === 0 && (
              <motion.div initial={{ opacity:0, x:-20 }} animate={{ opacity:1, x:0 }} className="space-y-6">
                <h2 className="font-display text-2xl font-light">Shipping Information</h2>
                <div className="grid grid-cols-2 gap-4">
                  <InputField label="First Name" value={shipping.firstName} onChange={setS('firstName')} />
                  <InputField label="Last Name" value={shipping.lastName} onChange={setS('lastName')} />
                </div>
                <InputField label="Email Address" value={shipping.email} onChange={setS('email')} type="email" />
                <InputField label="Phone Number" value={shipping.phone} onChange={setS('phone')} type="tel" />
                <InputField label="Street Address" value={shipping.address} onChange={setS('address')} />
                <div className="grid grid-cols-3 gap-4">
                  <InputField label="City" value={shipping.city} onChange={setS('city')} />
                  <InputField label="State" value={shipping.state} onChange={setS('state')} />
                  <InputField label="ZIP Code" value={shipping.zip} onChange={setS('zip')} />
                </div>
                <div>
                  <label className="block text-[10px] tracking-widest uppercase text-warm-gray mb-1.5">Country</label>
                  <select value={shipping.country} onChange={setS('country')} className="w-full border border-beige px-4 py-3 text-sm outline-none focus:border-charcoal bg-white">
                    {['Bangladesh','United States','United Kingdom','Germany','France','Australia','Canada','UAE'].map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setStep(1)} className="flex-1 py-4 bg-charcoal text-white text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">
                    Continue to Payment →
                  </button>
                </div>
              </motion.div>
            )}

            {step === 1 && (
              <motion.div initial={{ opacity:0, x:-20 }} animate={{ opacity:1, x:0 }} className="space-y-6">
                <h2 className="font-display text-2xl font-light">Payment Details</h2>
                <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 text-sm text-green-700">
                  <svg className="w-5 h-5 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
                  Secure 256-bit SSL encryption via Stripe
                </div>
                <InputField label="Cardholder Name" value={payment.name} onChange={setP('name')} placeholder="As on card" />
                <div>
                  <label className="block text-[10px] tracking-widest uppercase text-warm-gray mb-1.5">Card Number</label>
                  <input value={payment.card} onChange={e => setPayment(p => ({ ...p, card: e.target.value.replace(/\D/g,'').slice(0,16).replace(/(.{4})/g,'$1 ').trim() }))}
                    placeholder="1234 5678 9012 3456" maxLength={19}
                    className="w-full border border-beige px-4 py-3 text-sm outline-none focus:border-charcoal transition-colors bg-white font-mono" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <InputField label="Expiry (MM/YY)" value={payment.expiry} onChange={setP('expiry')} placeholder="12/28" />
                  <InputField label="CVV" value={payment.cvv} onChange={setP('cvv')} placeholder="123" type="password" />
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setStep(0)} className="px-8 py-4 border border-beige text-sm hover:bg-beige transition-colors">← Back</button>
                  <button onClick={() => setStep(2)} className="flex-1 py-4 bg-charcoal text-white text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">
                    Review Order →
                  </button>
                </div>
              </motion.div>
            )}

            {step === 2 && (
              <motion.div initial={{ opacity:0, x:-20 }} animate={{ opacity:1, x:0 }} className="space-y-6">
                <h2 className="font-display text-2xl font-light">Review Your Order</h2>
                <div className="bg-white border border-beige p-6 space-y-4">
                  <h3 className="text-[10px] tracking-widest uppercase text-warm-gray">Shipping To</h3>
                  <p className="text-sm">{shipping.firstName} {shipping.lastName}<br />{shipping.address}, {shipping.city}, {shipping.zip}<br />{shipping.country}</p>
                </div>
                <div className="bg-white border border-beige p-6 space-y-3">
                  {items.map(item => (
                    <div key={item.key} className="flex items-center gap-4">
                      <img src={item.images?.[0]} alt={item.name} className="w-16 h-20 object-cover bg-beige flex-shrink-0" onError={e => e.target.style.display='none'} />
                      <div className="flex-1">
                        <p className="text-sm font-medium">{item.name}</p>
                        <p className="text-xs text-warm-gray">Size: {item.size} · Qty: {item.qty}</p>
                      </div>
                      <p className="text-sm font-medium">{formatPrice(item.price * item.qty)}</p>
                    </div>
                  ))}
                </div>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setStep(1)} className="px-8 py-4 border border-beige text-sm hover:bg-beige transition-colors">← Back</button>
                  <button onClick={placeOrder} disabled={loading} className="flex-1 py-4 bg-gold text-white text-[11px] tracking-widest uppercase hover:bg-accent transition-colors disabled:opacity-60">
                    {loading ? 'Processing...' : `Place Order — ${formatPrice(grandTotal)}`}
                  </button>
                </div>
              </motion.div>
            )}
          </div>

          {/* Order Summary */}
          <div>
            <div className="bg-white border border-beige p-6 sticky top-24">
              <h3 className="font-display text-lg font-light mb-4">Order Summary</h3>
              <div className="space-y-3 mb-4 max-h-64 overflow-y-auto">
                {items.map(item => (
                  <div key={item.key} className="flex items-center gap-3">
                    <img src={item.images?.[0]} alt={item.name} className="w-12 h-14 object-cover bg-beige flex-shrink-0" onError={e => e.target.style.display='none'} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{item.name}</p>
                      <p className="text-xs text-warm-gray">× {item.qty}</p>
                    </div>
                    <p className="text-xs font-medium">{formatPrice(item.price * item.qty)}</p>
                  </div>
                ))}
              </div>
              <div className="border-t border-beige pt-4 space-y-2">
                <div className="flex justify-between text-sm text-warm-gray"><span>Subtotal</span><span>{formatPrice(subtotal)}</span></div>
                {discountAmount > 0 && <div className="flex justify-between text-sm text-green-600"><span>Discount</span><span>−{formatPrice(discountAmount)}</span></div>}
                <div className="flex justify-between text-sm text-warm-gray"><span>Shipping</span><span className={isFreeShipping ? 'text-green-600 font-medium' : ''}>{isFreeShipping ? 'Free' : formatPrice(15)}</span></div>
                <div className="flex justify-between text-base font-medium border-t border-beige pt-3 mt-2"><span>Total</span><span>{formatPrice(grandTotal)}</span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

