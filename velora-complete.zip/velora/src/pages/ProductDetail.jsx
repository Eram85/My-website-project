// src/pages/ProductDetail.jsx
import { useState, useEffect } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { motion } from 'framer-motion'
import toast from 'react-hot-toast'
import { PRODUCTS, getRelatedProducts } from '../data/products'
import { useCartStore, useWishlistStore, useUIStore } from '../context/useStore'
import { formatPrice } from '../utils'
import ProductCard from '../components/product/ProductCard'

const Stars = ({ r, s='text-base' }) => (
  <span className={`text-gold ${s}`}>{'★'.repeat(Math.floor(r))}{'☆'.repeat(5-Math.floor(r))}</span>
)

export default function ProductDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const product = PRODUCTS.find(p => p.id === id)
  const related = product ? getRelatedProducts(product, 4) : []

  const { addItem, openCart }    = useCartStore()
  const { toggle, isWishlisted } = useWishlistStore()
  const { addRecentlyViewed }    = useUIStore()

  const [selectedSize,  setSelectedSize]  = useState(null)
  const [selectedColor, setSelectedColor] = useState(null)
  const [activeImg,     setActiveImg]     = useState(0)
  const [qty,           setQty]           = useState(1)
  const [tab,           setTab]           = useState('description')
  const [zoomed,        setZoomed]        = useState(false)
  const [mousePos,      setMousePos]      = useState({ x:50, y:50 })
  const [reviewForm,    setReviewForm]    = useState({ rating:5, text:'' })
  const [reviews, setReviews] = useState([
    { id:1, name:'Emma K.',  rating:5, text:'Absolutely love this piece! Quality is incredible and it fits perfectly.', date:'May 2026',   verified:true },
    { id:2, name:'James L.', rating:4, text:'Great product, beautiful packaging. Delivery was incredibly fast too.',  date:'April 2026', verified:true },
  ])

  useEffect(() => {
    if (product) {
      addRecentlyViewed(product)
      setSelectedColor(product.colors?.[0] || null)
      setSelectedSize(null)
      setActiveImg(0)
      setQty(1)
      window.scrollTo({ top:0, behavior:'smooth' })
    }
  }, [id])

  if (!product) return (
    <div className="min-h-screen bg-cream pt-[72px] flex items-center justify-center">
      <div className="text-center">
        <p className="font-display text-3xl text-warm-gray mb-4">Product not found</p>
        <button onClick={() => navigate('/products')} className="border border-charcoal px-8 py-3 text-sm uppercase tracking-widest hover:bg-charcoal hover:text-white transition-all">Back to Shop</button>
      </div>
    </div>
  )

  const wishlisted = isWishlisted(product.id)

  const handleAddToCart = () => {
    if (!selectedSize && product.sizes?.length > 1) { toast.error('Please select a size'); return }
    for (let i = 0; i < qty; i++) addItem(product, selectedSize || product.sizes?.[0], selectedColor || '')
    toast.success(`${product.name} added to bag ✓`, { icon:'🛍' })
    openCart()
  }

  const handleMouseMove = e => {
    const rect = e.currentTarget.getBoundingClientRect()
    setMousePos({ x:((e.clientX-rect.left)/rect.width)*100, y:((e.clientY-rect.top)/rect.height)*100 })
  }

  const submitReview = () => {
    if (!reviewForm.text.trim()) { toast.error('Please write a review'); return }
    setReviews(prev => [{ id:Date.now(), name:'You', rating:reviewForm.rating, text:reviewForm.text, date:'Just now', verified:false }, ...prev])
    setReviewForm({ rating:5, text:'' })
    toast.success('Review submitted! Thank you.')
  }

  const colorHex = { Black:'#1A1A1A', White:'#F5F5F5', Beige:'#E8E2D9', Gold:'#C9A96E', Navy:'#1A2035', Rose:'#D4A5A5', Burgundy:'#6E1A2A', Olive:'#4A5230' }

  return (
    <div className="min-h-screen bg-cream pt-[72px]">
      {/* Breadcrumb */}
      <div className="bg-white border-b border-beige">
        <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-3">
          <nav className="flex items-center gap-2 text-xs text-warm-gray">
            <Link to="/" className="hover:text-charcoal transition-colors">Home</Link>
            <span>/</span>
            <Link to="/products" className="hover:text-charcoal transition-colors">Shop</Link>
            <span>/</span>
            <Link to={`/products?category=${product.category}`} className="hover:text-charcoal transition-colors capitalize">{product.category}</Link>
            <span>/</span>
            <span className="text-charcoal">{product.name}</span>
          </nav>
        </div>
      </div>

      <div className="max-w-screen-xl mx-auto px-6 lg:px-10 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14">

          {/* ── Images ─────────────────────────────── */}
          <div className="space-y-3">
            {/* Main image */}
            <div className="relative aspect-[4/5] overflow-hidden cursor-crosshair bg-beige"
              onMouseEnter={() => setZoomed(true)} onMouseLeave={() => setZoomed(false)} onMouseMove={handleMouseMove}>
              <img src={product.images?.[activeImg]} alt={product.name}
                className="w-full h-full object-cover transition-transform duration-150"
                style={{ transform: zoomed ? `scale(1.8) translate(${(50-mousePos.x)*0.25}%, ${(50-mousePos.y)*0.25}%)` : 'scale(1)' }} />
              {product.badge && (
                <span className={`absolute top-4 left-4 z-10 px-3 py-1 text-[10px] tracking-widest uppercase font-medium ${product.badge==='sale' ? 'bg-red-600 text-white' : product.badge==='hot' ? 'bg-gold text-white' : 'bg-charcoal text-white'}`}>
                  {product.badge}
                </span>
              )}
              {zoomed && <p className="absolute bottom-3 right-3 text-[10px] uppercase tracking-widest text-white/70 bg-black/40 px-2 py-1">Zoom active</p>}
            </div>
            {/* Thumbnails */}
            <div className="flex gap-2">
              {product.images?.map((img,i) => (
                <button key={i} onClick={() => setActiveImg(i)}
                  className={`w-20 h-24 flex-shrink-0 overflow-hidden border-2 transition-all ${activeImg===i ? 'border-charcoal' : 'border-transparent hover:border-beige'}`}>
                  <img src={img} alt="" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* ── Info ───────────────────────────────── */}
          <div>
            <p className="text-[10px] tracking-[0.3em] uppercase text-gold mb-2">{product.brand}</p>
            <h1 className="font-display text-3xl lg:text-4xl font-light mb-3 leading-tight">{product.name}</h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-5">
              <Stars r={product.rating} />
              <span className="text-sm text-warm-gray">({product.reviews} reviews)</span>
              <span className={`ml-auto text-[11px] uppercase tracking-wider font-medium ${product.inStock ? 'text-green-600' : 'text-red-500'}`}>
                ● {product.inStock ? 'In Stock' : 'Out of Stock'}
              </span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-4 mb-6 pb-6 border-b border-beige">
              <span className="font-display text-3xl">{formatPrice(product.price)}</span>
              {product.oldPrice && (
                <>
                  <span className="text-warm-gray line-through text-xl">{formatPrice(product.oldPrice)}</span>
                  <span className="bg-red-50 text-red-600 text-xs px-2 py-1 font-medium">Save {Math.round((1-product.price/product.oldPrice)*100)}%</span>
                </>
              )}
            </div>

            {/* Colors */}
            {product.colors?.length > 0 && (
              <div className="mb-6">
                <p className="text-[10px] tracking-widest uppercase text-warm-gray mb-3">Color: <span className="text-charcoal font-medium">{selectedColor}</span></p>
                <div className="flex gap-2 flex-wrap">
                  {product.colors.map(c => (
                    <button key={c} title={c} onClick={() => setSelectedColor(c)}
                      className={`w-9 h-9 rounded-full border-2 transition-all hover:scale-110 ${selectedColor===c ? 'border-charcoal' : 'border-transparent'}`}
                      style={{ background:colorHex[c]||'#8C8680', boxShadow:c==='White'?'inset 0 0 0 1px #ddd':'none' }} />
                  ))}
                </div>
              </div>
            )}

            {/* Sizes */}
            {product.sizes?.length > 0 && (
              <div className="mb-6">
                <div className="flex items-center justify-between mb-3">
                  <p className="text-[10px] tracking-widest uppercase text-warm-gray">Size: <span className="text-charcoal font-medium">{selectedSize || 'Select a size'}</span></p>
                  <button className="text-[11px] text-gold underline underline-offset-4 hover:text-accent transition-colors">Size Guide</button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {product.sizes.map(s => (
                    <button key={s} onClick={() => setSelectedSize(s)}
                      className={`min-w-[46px] h-11 px-3 text-sm font-medium border transition-all duration-200 ${selectedSize===s ? 'bg-charcoal text-white border-charcoal' : 'border-beige hover:border-charcoal bg-white'}`}>
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Qty */}
            <div className="flex items-center gap-5 mb-6">
              <div className="flex items-center border border-beige bg-white">
                <button onClick={() => setQty(q => Math.max(1,q-1))} className="w-11 h-11 flex items-center justify-center text-lg hover:bg-beige transition-colors">−</button>
                <span className="w-12 text-center text-sm font-medium">{qty}</span>
                <button onClick={() => setQty(q => q+1)} className="w-11 h-11 flex items-center justify-center text-lg hover:bg-beige transition-colors">+</button>
              </div>
              <span className="text-xs text-warm-gray">{product.reviews} people own this</span>
            </div>

            {/* CTAs */}
            <div className="space-y-3 mb-8">
              <button onClick={handleAddToCart} disabled={!product.inStock}
                className="w-full py-4 bg-charcoal text-white text-[11px] tracking-widest uppercase font-medium hover:bg-gold transition-colors duration-300 disabled:opacity-40">
                {product.inStock ? `Add to Bag — ${formatPrice(product.price*qty)}` : 'Out of Stock'}
              </button>
              <button onClick={() => { toggle(product); toast.success(wishlisted ? 'Removed from wishlist' : 'Added to wishlist ♥') }}
                className={`w-full py-3.5 border text-[11px] tracking-widest uppercase flex items-center justify-center gap-2 transition-all duration-200 ${wishlisted ? 'border-rose bg-rose/10' : 'border-beige hover:border-charcoal'}`}>
                {wishlisted ? '♥ Wishlisted' : '♡ Add to Wishlist'}
              </button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-2 gap-3 p-4 bg-white border border-beige mb-6">
              {[{icon:'🚚',label:'Free Shipping',sub:'Orders over $200'},{icon:'↩️',label:'30-Day Returns',sub:'Hassle-free'},{icon:'🔒',label:'Secure Payment',sub:'SSL encrypted'},{icon:'✓',label:'Authenticity',sub:'100% guaranteed'}].map(b => (
                <div key={b.label} className="flex items-center gap-3">
                  <span className="text-lg">{b.icon}</span>
                  <div><p className="text-xs font-medium">{b.label}</p><p className="text-[11px] text-warm-gray">{b.sub}</p></div>
                </div>
              ))}
            </div>

            <p className="text-xs text-warm-gray">SKU: {product.sku}</p>
          </div>
        </div>

        {/* ── Tabs ─────────────────────────────────── */}
        <div className="mt-16 border-t border-beige pt-10">
          <div className="flex gap-8 border-b border-beige mb-8">
            {['description','details','reviews'].map(t => (
              <button key={t} onClick={() => setTab(t)}
                className={`pb-4 text-[11px] tracking-widest uppercase font-medium transition-all border-b-2 -mb-px ${tab===t ? 'border-charcoal text-charcoal' : 'border-transparent text-warm-gray hover:text-charcoal'}`}>
                {t}{t==='reviews' ? ` (${reviews.length})` : ''}
              </button>
            ))}
          </div>

          {tab === 'description' && (
            <div className="max-w-2xl">
              <p className="text-[15px] text-warm-gray leading-relaxed">{product.description}</p>
            </div>
          )}

          {tab === 'details' && (
            <ul className="max-w-lg space-y-3">
              {(product.details || []).map((d,i) => (
                <li key={i} className="flex items-center gap-3 text-sm text-warm-gray border-b border-beige pb-3">
                  <span className="text-gold">✦</span> {d}
                </li>
              ))}
            </ul>
          )}

          {tab === 'reviews' && (
            <div className="space-y-8">
              {/* Summary */}
              <div className="flex items-center gap-8 p-6 bg-white border border-beige">
                <div className="text-center">
                  <div className="font-display text-5xl font-light text-gold">{product.rating}</div>
                  <Stars r={product.rating} s="text-sm" />
                  <p className="text-xs text-warm-gray mt-1">{product.reviews} reviews</p>
                </div>
                <div className="flex-1 space-y-2">
                  {[5,4,3,2,1].map(n => (
                    <div key={n} className="flex items-center gap-3">
                      <span className="text-xs w-3">{n}</span>
                      <span className="text-gold text-xs">★</span>
                      <div className="flex-1 h-1.5 bg-beige rounded-full overflow-hidden">
                        <div className="h-full bg-gold rounded-full" style={{ width:`${n===5?70:n===4?20:5}%` }} />
                      </div>
                      <span className="text-xs text-warm-gray w-8">{n===5?'70%':n===4?'20%':'5%'}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reviews list */}
              {reviews.map(rev => (
                <div key={rev.id} className="border-b border-beige pb-6">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 bg-beige rounded-full flex items-center justify-center font-display text-sm">{rev.name[0]}</div>
                      <div><p className="text-sm font-medium">{rev.name}</p><p className="text-xs text-warm-gray">{rev.date}</p></div>
                    </div>
                    {rev.verified && <span className="text-[10px] tracking-wider uppercase text-green-600 border border-green-200 px-2 py-0.5">Verified Purchase</span>}
                  </div>
                  <Stars r={rev.rating} s="text-sm" />
                  <p className="text-sm text-warm-gray leading-relaxed mt-2">{rev.text}</p>
                </div>
              ))}

              {/* Write review */}
              <div className="bg-cream p-6">
                <h3 className="font-display text-xl font-light mb-4">Write a Review</h3>
                <div className="flex gap-1 mb-4">
                  {[1,2,3,4,5].map(n => (
                    <button key={n} onClick={() => setReviewForm(f=>({...f,rating:n}))} className={`text-2xl transition-transform hover:scale-125 ${n<=reviewForm.rating ? 'text-gold' : 'text-beige'}`}>★</button>
                  ))}
                </div>
                <textarea value={reviewForm.text} onChange={e => setReviewForm(f=>({...f,text:e.target.value}))}
                  placeholder="Share your experience..." rows={4}
                  className="w-full border border-beige bg-white p-4 text-sm outline-none focus:border-charcoal transition-colors resize-none mb-4" />
                <button onClick={submitReview} className="border border-charcoal px-8 py-3 text-[11px] tracking-widest uppercase hover:bg-charcoal hover:text-white transition-all">Submit Review</button>
              </div>
            </div>
          )}
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div className="mt-20">
            <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">You May Also Like</p>
            <h2 className="font-display text-3xl font-light mb-8">Related Products</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-x-5 gap-y-10">
              {related.map((p,i) => <ProductCard key={p.id} product={p} index={i} />)}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
