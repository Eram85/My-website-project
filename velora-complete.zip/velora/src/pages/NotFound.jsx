import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
export default function NotFound() {
  return (
    <div className="min-h-screen bg-cream pt-[72px] flex items-center justify-center text-center px-4">
      <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }}>
        <p className="font-display text-[8rem] font-light text-beige leading-none">404</p>
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-3">Page Not Found</p>
        <h1 className="font-display text-4xl font-light mb-4">Lost in Style</h1>
        <p className="text-warm-gray mb-8 max-w-sm mx-auto">The page you're looking for doesn't exist, but our collection most definitely does.</p>
        <Link to="/" className="inline-flex items-center gap-3 bg-charcoal text-white px-10 py-4 text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">
          Back to VELORA →
        </Link>
      </motion.div>
    </div>
  )
}
