import { useLocation, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { formatPrice } from '../utils'

export default function OrderConfirmation() {
  const { state } = useLocation()
  const orderId = state?.orderId || 'VLR-DEMO123'
  const total = state?.total || 0
  const email = state?.email || 'your email'

  return (
    <div className="min-h-screen bg-cream pt-[72px] flex items-center justify-center px-4">
      <motion.div initial={{ opacity:0, scale:0.95 }} animate={{ opacity:1, scale:1 }} className="max-w-lg w-full bg-white p-12 text-center shadow-sm">
        <motion.div initial={{ scale:0 }} animate={{ scale:1 }} transition={{ delay:0.2, type:'spring' }}
          className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-10 h-10 text-green-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
        </motion.div>
        <p className="text-[11px] tracking-[0.4em] uppercase text-gold mb-2">Order Confirmed</p>
        <h1 className="font-display text-4xl font-light mb-4">Thank You!</h1>
        <p className="text-warm-gray text-sm leading-relaxed mb-6">
          Your order has been placed successfully. A confirmation has been sent to <strong>{email}</strong>.
        </p>
        <div className="bg-cream p-6 mb-6 text-left space-y-3">
          <div className="flex justify-between text-sm"><span className="text-warm-gray">Order ID</span><span className="font-medium font-mono">{orderId}</span></div>
          <div className="flex justify-between text-sm"><span className="text-warm-gray">Amount Paid</span><span className="font-medium">{formatPrice(total)}</span></div>
          <div className="flex justify-between text-sm"><span className="text-warm-gray">Estimated Delivery</span><span className="font-medium">3–5 Business Days</span></div>
          <div className="flex justify-between text-sm"><span className="text-warm-gray">Payment</span><span className="text-green-600 font-medium">✓ Confirmed</span></div>
        </div>

        {/* Delivery steps */}
        <div className="flex items-center justify-between mb-8 relative">
          <div className="absolute top-4 left-8 right-8 h-px bg-beige" />
          {['Order Placed','Processing','Shipped','Delivered'].map((s, i) => (
            <div key={s} className="flex flex-col items-center gap-2 relative z-10">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-medium ${i === 0 ? 'bg-gold text-white' : 'bg-beige text-warm-gray'}`}>
                {i === 0 ? '✓' : i + 1}
              </div>
              <span className="text-[10px] text-warm-gray text-center">{s}</span>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <Link to="/account" className="flex-1 py-3.5 border border-beige text-[11px] tracking-widest uppercase hover:bg-beige transition-colors">Track Order</Link>
          <Link to="/products" className="flex-1 py-3.5 bg-charcoal text-white text-[11px] tracking-widest uppercase hover:bg-gold transition-colors">Continue Shopping</Link>
        </div>
      </motion.div>
    </div>
  )
}
