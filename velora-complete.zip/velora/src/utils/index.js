export const formatPrice = (amount, currency = 'USD') =>
  new Intl.NumberFormat('en-US', { style:'currency', currency, maximumFractionDigits:0 }).format(amount)

export const truncate = (str, n) => str.length > n ? str.slice(0, n) + '...' : str

export const discountPct = (price, oldPrice) =>
  oldPrice ? Math.round((1 - price / oldPrice) * 100) : 0

export const generateOrderId = () =>
  'VLR-' + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2,5).toUpperCase()

export const isValidEmail = email => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)

export const formatDate = date => {
  const d = date?.toDate ? date.toDate() : new Date(date)
  return d.toLocaleDateString('en-US', { year:'numeric', month:'long', day:'numeric' })
}

export const scrollToTop = () => window.scrollTo({ top:0, behavior:'smooth' })

export const STATUS_COLORS = {
  pending:    { bg:'#FFF3CD', text:'#856404' },
  processing: { bg:'#CCE5FF', text:'#004085' },
  shipped:    { bg:'#D4EDDA', text:'#155724' },
  delivered:  { bg:'#D1ECF1', text:'#0C5460' },
  cancelled:  { bg:'#F8D7DA', text:'#721C24' },
}
