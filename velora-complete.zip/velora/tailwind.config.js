/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['"Cormorant Garamond"', 'serif'],
        body: ['"DM Sans"', 'sans-serif'],
      },
      colors: {
        cream: '#FAF8F5',
        beige: '#E8E2D9',
        gold: '#C9A96E',
        'gold-light': '#E8D5B0',
        accent: '#B8956A',
        charcoal: '#1A1A1A',
        'warm-gray': '#8C8680',
        rose: '#D4A5A5',
        velora: {
          50: '#FAF8F5',
          100: '#F0EBE3',
          200: '#E8E2D9',
          300: '#D4C9B8',
          400: '#C9A96E',
          500: '#B8956A',
          600: '#8C8680',
          700: '#4A4540',
          800: '#2A2520',
          900: '#1A1A1A',
        }
      },
      animation: {
        'fade-up': 'fadeUp 0.6s ease forwards',
        'fade-in': 'fadeIn 0.4s ease forwards',
        'slide-right': 'slideRight 0.4s ease forwards',
        'ticker': 'ticker 30s linear infinite',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
        'spin-slow': 'spin 8s linear infinite',
      },
      keyframes: {
        fadeUp: { from: { opacity: 0, transform: 'translateY(20px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        slideRight: { from: { opacity: 0, transform: 'translateX(20px)' }, to: { opacity: 1, transform: 'translateX(0)' } },
        ticker: { from: { transform: 'translateX(0)' }, to: { transform: 'translateX(-50%)' } },
      },
      backdropBlur: { xs: '2px' },
      transitionTimingFunction: { 'luxury': 'cubic-bezier(0.25, 0.46, 0.45, 0.94)' },
    },
  },
  plugins: [],
}
