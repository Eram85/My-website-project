# VELORA — Luxury Fashion eCommerce

A production-ready luxury fashion eCommerce website built with React + Vite.

## 🚀 Quick Start

```bash
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

## 🔧 Setup

### 1. Firebase (Authentication + Database)
1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Create a new project
3. Enable **Authentication** → Email/Password + Google
4. Enable **Firestore Database**
5. Copy `.env.example` to `.env` and fill in your credentials

### 2. Stripe (Payments)
1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Get your **Publishable Key**
3. Add it to `.env` as `VITE_STRIPE_PUBLISHABLE_KEY`

## 📁 Project Structure

```
src/
├── components/
│   ├── layout/     Navbar, Footer
│   ├── product/    ProductCard, QuickViewModal
│   ├── cart/       CartDrawer
│   └── ui/         FloatingChat, ScrollProgress
├── pages/          All route pages
├── context/        Zustand stores (cart, wishlist, UI)
├── firebase/       Auth + Firestore services
├── data/           Product catalogue + dummy data
├── hooks/          Custom React hooks
└── utils/          Helper functions
```

## ✨ Features

- 🛍 Full product catalogue with real Unsplash images
- 🔍 Live search with debounce
- 🛒 Animated cart drawer with coupon system
- ❤️ Wishlist with persistent storage
- 🔐 Firebase Auth (email + Google)
- 💳 Stripe checkout integration
- 👗 AI Outfit Recommender
- 📊 Admin dashboard with charts
- 📱 Fully responsive
- 🌙 Dark mode ready

## 🎨 Tech Stack

- **React 18** + **Vite**
- **Tailwind CSS** — styling
- **Framer Motion** — animations
- **Zustand** — state management
- **Firebase** — auth + database
- **Stripe** — payments
- **Recharts** — admin analytics
- **React Router v6**
